# Lull

A calm Android browser built from the same parts as Firefox for Android: Firefox's engine (GeckoView) and Mozilla Android Components. It takes its ideas from desktop Zen Browser and fits them to a phone.

## What it does

**From Firefox**
- **Firefox Account and Sync:** bookmarks, history, saved passwords and open tabs sync with Firefox on your computer. You can also see and open tabs from your other devices.
- **Extensions:** install any Android-compatible add-on from addons.mozilla.org (uBlock Origin, Bitwarden, Dark Reader and others), or pick from Mozilla's recommended list. You can turn extensions on and off, open their settings, use their toolbar buttons and pop-ups from the menu, and remove them.
- **Passwords:** Lull offers to save logins, fills them in for you, and keeps a password list behind your fingerprint or screen lock.
- **Everyday browsing:** bookmarks, history, private tabs, find in page, desktop site, and downloads that keep going in the background. Page pop-ups, file uploads, and camera, microphone, location and notification prompts all work.
- **Privacy:** strict tracking protection is on by default, and you can switch it off in Settings.

**Zen-style features**
- **Workspaces:** each workspace has its own colour, tabs, Essentials and search engine. Turning on *Separate logins* lets you sign in to a second account in that workspace.
- **Essentials** (pinned favourite sites) and **pinned tabs**.
- **Split view:** two pages on screen at once, with a drag handle to resize them.
- **Glance:** long-press a link to preview it, then close it, split it or open it as a tab.
- **One bottom bar:** swipe it sideways to change workspace or up to open your tabs. It shrinks to a pill while you scroll.

## Get the app

GitHub builds the app on every push to `main`, and again every Monday so it picks up Firefox security fixes.

1. On your phone, open this repo's **Releases** page.
2. Download the latest `lull-N.apk` and open it. Allow "install unknown apps" if Android asks.

New builds install over the old one.

## Important notes

- **Firefox Account sign-in** uses the public client ID of Mozilla's sample browser, because Mozilla doesn't issue IDs to individual developers. Community Firefox-based browsers commonly do this. Mozilla could block it at any time, and if that happens sign-in stops working. Everything else keeps working.
- **Signing key:** `app/lull.keystore` is in the repo so every build can update the last one. That's fine while the repo is private. Before you make it public or share the APK, move the key into GitHub Secrets.
- **Firefox version:** the app uses the newest 159.x release of Mozilla's components. Moving to Firefox 160 or later means updating the version in `app/build.gradle.kts`, plus the Android Gradle Plugin and Kotlin versions in `build.gradle.kts` to whatever that release uses.

## Credits

Lull builds on GeckoView and Mozilla Android Components, both under the Mozilla Public License 2.0. Its component wiring follows Mozilla's [reference-browser](https://github.com/mozilla-mobile/reference-browser) sample.

## Project layout

```
app/src/main/java/app/lull/browser/
  LullApp.kt                 startup: Sync's Rust layer, tab restore, extension support
  Components.kt              engine, tab store, storage, accounts, add-ons
  LullState.kt               workspaces, Essentials, pins, split view, Glance
  MainActivity.kt            page dialogs, permissions, downloads, pop-up windows
  LullRequestInterceptor.kt  finishes Firefox sign-in; error pages
  DownloadService.kt         background downloads
  ui/BrowserScreen.kt        page area, split panes, bottom bar, start page
  ui/Sheets.kt               address bar, tab sheet, menu, find, Glance, extension pop-ups
  ui/Extensions.kt           extensions manager and install prompts
  ui/AccountScreen.kt        Firefox Account and Sync
  ui/LibraryScreens.kt       bookmarks, history, passwords, settings
  ui/WorkspacesScreen.kt
```
