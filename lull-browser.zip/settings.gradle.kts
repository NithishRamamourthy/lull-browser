pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Firefox's engine (GeckoView) and Mozilla Android Components, release builds only.
        maven { url = uri("https://maven.mozilla.org/maven2/") }
    }
}

rootProject.name = "lull-browser"
include(":app")
