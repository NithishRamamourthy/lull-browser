package app.lull.browser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.lull.browser.LullState
import app.lull.browser.SEARCH_ENGINES
import app.lull.browser.WORKSPACE_COLORS
import app.lull.browser.Workspace
import app.lull.browser.hostOf
import mozilla.components.browser.state.state.BrowserState

/** Each workspace has its own tabs, Essentials, colour, search engine and (optionally) logins. */
@Composable
fun WorkspacesScreen(lull: LullState, state: BrowserState, onDone: () -> Unit) {
    var editingId by remember { mutableStateOf(lull.currentWorkspace.takeIf { !it.isPrivate }?.id ?: lull.workspaces.first().id) }
    val editing = lull.workspaces.firstOrNull { it.id == editingId } ?: lull.workspaces.first()

    Column(
        Modifier.fillMaxSize().background(Lull.Bg).systemBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Workspaces", color = Lull.Text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            Box(
                Modifier.height(44.dp).clip(RoundedCornerShape(14.dp)).background(Lull.Chip).clickable(onClick = onDone)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Done", color = Lull.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
        }

        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(lull.workspaces, key = { it.id }) { ws ->
                WorkspaceCard(lull, state, ws, selected = ws.id == editing.id) {
                    editingId = ws.id
                    lull.switchWorkspace(ws.id)
                }
            }
            item {
                Box(
                    Modifier.size(120.dp, 260.dp).clip(RoundedCornerShape(26.dp)).background(Lull.Chip)
                        .clickable { val ws = lull.addWorkspace(); editingId = ws.id; lull.switchWorkspace(ws.id) }
                        .semantics { contentDescription = "New workspace" },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Add, null, tint = Lull.Text, modifier = Modifier.size(32.dp)) }
            }
        }

        WorkspaceSettings(lull, editing)
    }
}

@Composable
private fun WorkspaceCard(lull: LullState, state: BrowserState, ws: Workspace, selected: Boolean, onClick: () -> Unit) {
    val color = Color(ws.color)
    val tabs = lull.tabsIn(state, ws.id)
    Column(
        Modifier.width(250.dp).height(260.dp).clip(RoundedCornerShape(26.dp))
            .background(color.copy(alpha = 0.16f).compositeOver(Lull.Bg))
            .then(if (selected) Modifier.border(2.dp, color, RoundedCornerShape(26.dp)) else Modifier)
            .clickable(onClick = onClick)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(color))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(ws.name, color = Lull.Text, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                Text("${tabs.size} tabs · ${ws.essentials.size} essentials", color = Lull.Muted, fontSize = 13.sp)
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            tabs.take(3).forEach { t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SiteIcon(t.content.url, t.content.icon, 24)
                    Spacer(Modifier.width(8.dp))
                    Text(t.content.title.ifBlank { hostOf(t.content.url).ifEmpty { "New tab" } }, color = Lull.Text, fontSize = 13.sp, maxLines = 1)
                }
            }
            if (tabs.size > 3) Text("+${tabs.size - 3} more", color = Lull.Muted, fontSize = 13.sp)
        }
        Text(
            if (ws.separateLogins) "Separate logins" else "Shared logins",
            color = Lull.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun WorkspaceSettings(lull: LullState, ws: Workspace) {
    Column(
        Modifier.padding(horizontal = 20.dp).clip(RoundedCornerShape(22.dp)).background(Lull.Bar).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("${ws.name} settings", color = Lull.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold)

        TextField(
            value = ws.name, onValueChange = { ws.name = it.take(24); lull.persist() },
            label = { Text("Name") }, singleLine = true, colors = lullFieldColors(Color(ws.color)), shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Colour", color = Lull.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            WORKSPACE_COLORS.forEach { c ->
                val on = ws.color == c
                Box(
                    Modifier.size(44.dp).clip(CircleShape).clickable { ws.color = c; lull.persist() }
                        .semantics { contentDescription = "Colour" + if (on) ", selected" else "" },
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        Modifier.size(26.dp).clip(CircleShape).background(Color(c))
                            .then(if (on) Modifier.border(2.dp, Lull.Text, CircleShape) else Modifier),
                        contentAlignment = Alignment.Center,
                    ) { if (on) Icon(Icons.Rounded.Check, null, tint = Lull.Bg, modifier = Modifier.size(16.dp)) }
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Default search", color = Lull.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            SEARCH_ENGINES.keys.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { name ->
                        val on = ws.searchEngine == name
                        Box(
                            Modifier.height(40.dp).clip(CircleShape).background(if (on) Color(ws.color) else Lull.Chip)
                                .clickable { ws.searchEngine = name; lull.persist() }.padding(horizontal = 14.dp),
                            contentAlignment = Alignment.Center,
                        ) { Text(name, color = if (on) Lull.OnAccent else Lull.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Separate logins", color = Lull.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Keep this workspace's cookies and sign-ins apart, so you can use a second account. Applies to new tabs.",
                    color = Lull.Muted, fontSize = 13.sp,
                )
            }
            Switch(checked = ws.separateLogins, onCheckedChange = { ws.separateLogins = it; lull.persist() })
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { lull.closeUnpinned(ws.id) }, modifier = Modifier.weight(1f).height(48.dp)) {
                Text("Close unpinned tabs", color = Lull.Text)
            }
            if (lull.workspaces.size > 1) {
                OutlinedButton(onClick = { lull.deleteWorkspace(ws) }, modifier = Modifier.height(48.dp)) {
                    Icon(Icons.Rounded.Delete, "Delete workspace", tint = Color(0xFFF09AB8))
                }
            }
        }
    }
}
