package app.lull.browser.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Colours from the mockup. */
object Lull {
    val Bg = Color(0xFF18171C)
    val Sheet = Color(0xFF1E1D23)
    val Bar = Color(0xFF232228)
    val Field = Color(0xFF2F2E35)
    val Chip = Color(0xFF2A2930)
    val Text = Color(0xFFEEECF2)
    val Muted = Color(0xFFABA8B5)
    val Faint = Color(0xFF4A4950)
    val OnAccent = Color(0xFF14231C)
    val Page = Color(0xFFF4F2EE)
}

@Composable
fun LullTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF8ED1B2),
            onPrimary = Lull.OnAccent,
            background = Lull.Bg,
            surface = Lull.Sheet,
            surfaceContainerLow = Lull.Sheet,
            surfaceContainer = Lull.Bar,
            surfaceContainerHigh = Lull.Chip,
            onSurface = Lull.Text,
            onSurfaceVariant = Lull.Muted,
        ),
        content = content,
    )
}
