package app.lull.browser.ui

import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.lull.browser.LullEntryPoint
import app.lull.browser.LullState
import app.lull.browser.components
import kotlinx.coroutines.launch
import mozilla.components.concept.sync.AccountObserver
import mozilla.components.concept.sync.AuthType
import mozilla.components.concept.sync.OAuthAccount
import mozilla.components.concept.sync.Profile
import mozilla.components.service.fxa.sync.SyncReason
import mozilla.components.service.fxa.sync.SyncStatusObserver
import mozilla.components.service.fxa.sync.getLastSynced

/** Sign in to your Firefox Account and sync bookmarks, history, passwords and tabs. */
@Composable
fun AccountScreen(lull: LullState, onDone: () -> Unit) {
    val context = LocalContext.current
    val c = context.components
    val manager = c.accountManager
    val scope = rememberCoroutineScope()
    val owner = LocalLifecycleOwner.current

    var signedIn by remember { mutableStateOf(manager.authenticatedAccount() != null) }
    var needsReauth by remember { mutableStateOf(manager.accountNeedsReauth()) }
    var accountProfile by remember { mutableStateOf(manager.accountProfile()) }
    var syncing by remember { mutableStateOf(manager.isSyncActive()) }
    var lastSynced by remember { mutableLongStateOf(getLastSynced(context)) }
    var syncError by remember { mutableStateOf(false) }

    DisposableEffect(manager) {
        val accountObserver = object : AccountObserver {
            override fun onAuthenticated(account: OAuthAccount, authType: AuthType) { signedIn = true; needsReauth = false }
            override fun onLoggedOut() { signedIn = false; accountProfile = null }
            override fun onProfileUpdated(profile: Profile) { accountProfile = profile }
            override fun onAuthenticationProblems() { needsReauth = true }
        }
        manager.register(accountObserver)
        val syncObserver = object : SyncStatusObserver {
            override fun onStarted() { syncing = true; syncError = false }
            override fun onIdle() { syncing = false; lastSynced = getLastSynced(context) }
            override fun onError(error: Exception?) { syncing = false; syncError = true }
        }
        manager.registerForSyncEvents(syncObserver, owner, autoPause = true)
        onDispose {
            manager.unregister(accountObserver)
            manager.unregisterForSyncEvents(syncObserver)
        }
    }

    FullScreenPage {
        ScreenHeader("Firefox Account", onDone)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (!signedIn) {
                Icon(Icons.Rounded.Sync, null, tint = Color(lull.currentWorkspace.color), modifier = Modifier.size(48.dp))
                Text("Sync with Firefox", color = Lull.Text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "Sign in with your Firefox Account to bring your bookmarks, history, saved passwords and open tabs " +
                        "from Firefox on your computer, and keep them in step.",
                    color = Lull.Muted, fontSize = 15.sp,
                )
                Button(
                    onClick = {
                        c.accountsAuthFeature.beginAuthentication(context, LullEntryPoint.Menu)
                        onDone()
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text("Sign in", fontWeight = FontWeight.Bold) }
                Text(
                    "Sign-in opens Mozilla's login page in a new tab and comes back here when you're done. " +
                        "You can also scan the QR code from Firefox on your computer at firefox.com/pair.",
                    color = Lull.Muted, fontSize = 13.sp,
                )
                return@Column
            }

            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Lull.Bar).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.AccountCircle, null, tint = Lull.Text, modifier = Modifier.size(44.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(accountProfile?.displayName ?: accountProfile?.email ?: "Signed in", color = Lull.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    accountProfile?.email?.let { Text(it, color = Lull.Muted, fontSize = 13.sp) }
                }
            }

            if (needsReauth) {
                Text("Firefox needs you to sign in again.", color = Color(0xFFF2B872), fontSize = 15.sp)
                Button(onClick = { c.accountsAuthFeature.beginAuthentication(context, LullEntryPoint.Menu); onDone() }) {
                    Text("Sign in again")
                }
            }

            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Lull.Bar).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Syncing", color = Lull.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                listOf("Bookmarks", "History", "Passwords", "Open tabs").forEach {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(22.dp).clip(CircleShape).background(Color(lull.currentWorkspace.color)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Check, null, tint = Lull.OnAccent, modifier = Modifier.size(14.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(it, color = Lull.Text, fontSize = 15.sp)
                    }
                }
                Text(
                    when {
                        syncing -> "Syncing now…"
                        syncError -> "The last sync didn't finish. Try again."
                        lastSynced > 0 -> "Last synced " + DateUtils.getRelativeTimeSpanString(lastSynced)
                        else -> "Not synced yet"
                    },
                    color = Lull.Muted, fontSize = 13.sp,
                )
                Button(
                    onClick = { scope.launch { manager.syncNow(SyncReason.User) } },
                    enabled = !syncing,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (syncing) "Syncing…" else "Sync now") }
            }

            OutlinedButton(
                onClick = { scope.launch { manager.logout() } },
                modifier = Modifier.fillMaxWidth().height(48.dp),
            ) { Text("Sign out", color = Lull.Text) }
            Text(
                "Signing out keeps what's already on this phone. Lull uses Mozilla's sample-app account ID; " +
                    "if Mozilla ever blocks it, sign-in will stop working until the app is updated.",
                color = Lull.Muted, fontSize = 12.sp,
            )
        }
    }
}

