package app.lull.browser

import android.app.Application
import android.content.Context
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import mozilla.components.browser.state.action.SystemAction
import mozilla.components.feature.addons.update.GlobalAddonDependencyProvider
import mozilla.components.support.AppServicesInitializer
import mozilla.components.support.base.log.Log
import mozilla.components.support.base.log.sink.AndroidLogSink
import mozilla.components.support.ktx.android.content.isMainProcess
import mozilla.components.support.ktx.android.content.runOnlyInMainProcess
import mozilla.components.support.rusthttp.RustHttpConfig
import mozilla.components.support.webextensions.WebExtensionSupport
import java.util.concurrent.TimeUnit

class LullApp : Application() {

    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main + CoroutineExceptionHandler { _, e ->
            android.util.Log.e("Lull", "Background task failed", e)
        },
    )

    val components by lazy { Components(this, scope) }

    override fun onCreate() {
        super.onCreate()
        // Rust parts of Sync (bookmarks, history, passwords) must start before anything else touches them.
        AppServicesInitializer.init(AppServicesInitializer.Config(crashReporting = null))
        RustHttpConfig.setClient(lazy { components.client })
        Log.addSink(AndroidLogSink())

        // Gecko runs pages in child processes; only the main process sets up the browser.
        if (!isMainProcess()) return

        components.engine.warmUp()
        restoreTabs()

        GlobalAddonDependencyProvider.initialize(components.addonManager, components.addonUpdater)
        WebExtensionSupport.initialize(
            runtime = components.engine,
            store = components.store,
            onNewTabOverride = { _, engineSession, url, selected, private ->
                components.lull.newTabForExtension(url, engineSession, selected, private)
            },
            onCloseTabOverride = { _, tabId -> components.tabsUseCases.removeTab(tabId) },
            onSelectTabOverride = { _, tabId -> components.lull.select(tabId) },
            onExtensionsLoaded = { extensions -> components.addonUpdater.registerForFutureUpdates(extensions) },
            onUpdatePermissionRequest = components.addonUpdater::onUpdatePermissionRequest,
        )

        // Starts the account manager so Sync runs in the background if you're signed in.
        components.accountManager
    }

    private fun restoreTabs() = scope.launch {
        components.tabsUseCases.restore(components.sessionStorage)
        components.lull.onTabsRestored()
        components.sessionStorage.autoSave(components.store)
            .periodicallyInForeground(interval = 30, unit = TimeUnit.SECONDS)
            .whenGoingToBackground()
            .whenSessionsChange()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        runOnlyInMainProcess {
            components.store.dispatch(SystemAction.LowMemoryAction(level))
        }
    }
}

val Context.components: Components get() = (applicationContext as LullApp).components
