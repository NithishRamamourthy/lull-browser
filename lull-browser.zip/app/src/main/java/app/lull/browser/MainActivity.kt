package app.lull.browser

import android.app.SearchManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import mozilla.components.feature.downloads.DownloadsFeature
import mozilla.components.feature.downloads.manager.FetchDownloadManager
import mozilla.components.feature.prompts.PromptFeature
import mozilla.components.feature.sitepermissions.SitePermissionsFeature
import mozilla.components.feature.tabs.WindowFeature
import mozilla.components.service.sync.logins.DefaultLoginValidationDelegate
import mozilla.components.support.base.feature.LifecycleAwareFeature
import mozilla.components.support.webextensions.WebExtensionPopupObserver
import app.lull.browser.ui.BrowserScreen
import app.lull.browser.ui.LullTheme

/**
 * The one screen. It hosts Mozilla's page features (pop-up dialogs, site permission prompts,
 * downloads, new windows) and draws Lull's interface with Compose.
 */
class MainActivity : AppCompatActivity() {

    private val c get() = components

    private val requestPrompts: ActivityResultLauncher<Array<String>> = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        promptFeature.onPermissionsResult(it.keys.toTypedArray(), it.grants())
    }
    private val requestSite: ActivityResultLauncher<Array<String>> = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        sitePermissionsFeature.onPermissionsResult(it.keys.toTypedArray(), it.grants())
    }
    private val requestDownload: ActivityResultLauncher<Array<String>> = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        downloadsFeature.onPermissionsResult(it.keys.toTypedArray(), it.grants())
    }

    /** Alerts, confirm boxes, file pickers, date pickers, and saving/filling passwords. */
    private val promptFeature: PromptFeature by lazy {
        PromptFeature(
            activity = this,
            store = c.store,
            fragmentManager = supportFragmentManager,
            tabsUseCases = c.tabsUseCases,
            loginValidationDelegate = DefaultLoginValidationDelegate(c.lazyLoginsStorage),
            isLoginAutofillEnabled = { c.prefs.loginAutofill },
            isSaveLoginEnabled = { c.prefs.loginAutofill },
            isSuggestEmailMaskEnabled = { false },
            isEmailMaskFeatureEnabled = { false },
            fileUploadsDirCleaner = c.fileUploadsDirCleaner,
            onNeedToRequestPermissions = { requestPrompts.launch(it) },
        )
    }

    /** Camera, microphone, location and notification requests from websites. */
    private val sitePermissionsFeature: SitePermissionsFeature by lazy {
        SitePermissionsFeature(
            context = this,
            storage = c.sitePermissionsStorage,
            fragmentManager = supportFragmentManager,
            onNeedToRequestPermissions = { requestSite.launch(it) },
            onShouldShowRequestPermissionRationale = { shouldShowRequestPermissionRationale(it) },
            store = c.store,
        )
    }

    private val downloadsFeature: DownloadsFeature by lazy {
        DownloadsFeature(
            applicationContext = applicationContext,
            store = c.store,
            useCases = c.downloadsUseCases,
            onNeedToRequestPermissions = { requestDownload.launch(it) },
            downloadFileUtils = c.downloadFileUtils,
            downloadManager = FetchDownloadManager(
                applicationContext, c.store, DownloadService::class, notificationsDelegate = c.notificationsDelegate,
            ),
            fragmentManager = supportFragmentManager,
        )
    }

    /** Opens pop-up windows (target=_blank, window.open) as tabs and closes them on window.close. */
    private val windowFeature: WindowFeature by lazy { WindowFeature(c.store, c.tabsUseCases) }

    /** An extension's toolbar button opened its pop-up. */
    private val popupObserver: WebExtensionPopupObserver by lazy {
        WebExtensionPopupObserver(c.store, onOpenPopup = { ext -> c.lull.popupExtensionId = ext.id })
    }

    private val features: List<LifecycleAwareFeature> by lazy {
        listOf(promptFeature, sitePermissionsFeature, downloadsFeature, windowFeature, popupObserver)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleIntent(intent)

        setContent {
            LullTheme {
                BrowserScreen(
                    onFullScreen = ::setSystemBarsHidden,
                    onExit = { moveTaskToBack(true) },
                    consumeBack = { promptFeature.onBackPressed() },
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        features.forEach { it.start() }
    }

    override fun onStop() {
        super.onStop()
        features.forEach { it.stop() }
        c.lull.persist()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    @Deprecated("File pickers in web pages still report back through this.")
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (!promptFeature.onActivityResult(requestCode, data, resultCode)) {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    /** Links opened from other apps, and web searches, open in a new tab. */
    private fun handleIntent(intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_VIEW -> intent.dataString?.let { c.lull.openFromOutside(it) }
            Intent.ACTION_WEB_SEARCH, Intent.ACTION_SEARCH ->
                intent.getStringExtra(SearchManager.QUERY)?.let { c.lull.openFromOutside(c.lull.resolveInput(it)) }
        }
    }

    private fun setSystemBarsHidden(hidden: Boolean) {
        val ctl = WindowCompat.getInsetsController(window, window.decorView)
        if (hidden) {
            ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            ctl.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}

private fun Map<String, Boolean>.grants(): IntArray =
    values.map { if (it) PackageManager.PERMISSION_GRANTED else PackageManager.PERMISSION_DENIED }.toIntArray()
