package app.lull.browser.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.lull.browser.LullState
import app.lull.browser.components
import mozilla.components.browser.state.action.WebExtensionAction
import mozilla.components.browser.state.state.BrowserState
import mozilla.components.browser.state.state.extension.WebExtensionPromptRequest
import mozilla.components.concept.engine.webextension.InstallationMethod
import mozilla.components.concept.engine.webextension.PermissionPromptResponse
import mozilla.components.feature.addons.Addon
import mozilla.components.feature.addons.ui.displayName
import mozilla.components.feature.addons.ui.summary

/** Shared top bar for the full-screen pages. */
@Composable
fun ScreenHeader(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Lull.Text) }
        Text(title, color = Lull.Text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun FullScreenPage(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Lull.Bg).systemBarsPadding().imePadding(), content = content)
}

// ---------------- extensions manager ----------------

/** Installed extensions (on/off, settings, remove) and Mozilla's recommended ones to install. */
@Composable
fun ExtensionsScreen(lull: LullState, onDone: () -> Unit) {
    val context = LocalContext.current
    val c = context.components
    var addons by remember { mutableStateOf<List<Addon>?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(reload) {
        addons = try { c.addonManager.getAddons() } catch (e: Exception) { emptyList() }
    }
    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    FullScreenPage {
        ScreenHeader("Extensions", onDone)
        val list = addons
        if (list == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@FullScreenPage
        }
        val installed = list.filter { it.isInstalled() }
        val recommended = list.filter { !it.isInstalled() }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { SectionLabel("Installed") }
            if (installed.isEmpty()) item { Text("No extensions yet.", color = Lull.Muted, modifier = Modifier.padding(vertical = 8.dp)) }
            items(installed, key = { "i" + it.id }) { addon ->
                AddonRow(addon) {
                    Switch(
                        checked = addon.isEnabled(),
                        onCheckedChange = { on ->
                            if (on) c.addonManager.enableAddon(addon, onSuccess = { reload++ }, onError = { toast("Couldn't turn it on") })
                            else c.addonManager.disableAddon(addon, onSuccess = { reload++ }, onError = { toast("Couldn't turn it off") })
                        },
                    )
                    val options = addon.installedState?.optionsPageUrl
                    if (!options.isNullOrBlank()) {
                        IconButton(onClick = { lull.newTab(options); onDone() }) {
                            Icon(Icons.Rounded.Settings, "Extension settings", tint = Lull.Muted)
                        }
                    }
                    IconButton(onClick = {
                        c.addonManager.uninstallAddon(addon, onSuccess = { reload++ }, onError = { _, _ -> toast("Couldn't remove it") })
                    }) { Icon(Icons.Rounded.Delete, "Remove extension", tint = Lull.Muted) }
                }
            }
            item { Spacer(Modifier.height(8.dp)); SectionLabel("Recommended by Mozilla") }
            items(recommended, key = { "r" + it.id }) { addon ->
                AddonRow(addon) {
                    if (busy == addon.id) {
                        CircularProgressIndicator(Modifier.size(24.dp))
                    } else {
                        FilledTonalButton(onClick = {
                            busy = addon.id
                            c.addonManager.installAddon(
                                addon.downloadUrl,
                                InstallationMethod.MANAGER,
                                onSuccess = { busy = null; reload++; toast("${it.displayName(context)} added") },
                                onError = { busy = null; toast("Couldn't add this extension") },
                            )
                        }) { Text("Add") }
                    }
                }
            }
            item {
                OutlinedButton(
                    onClick = { lull.newTab("https://addons.mozilla.org/android/"); onDone() },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                ) { Text("Find more on addons.mozilla.org", color = Lull.Text) }
            }
        }
    }
}

@Composable
private fun AddonRow(addon: Addon, trailing: @Composable RowScope.() -> Unit) {
    val context = LocalContext.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Lull.Bar).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AddonIcon(addon.installedState?.icon ?: addon.icon)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(addon.displayName(context), color = Lull.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            addon.summary(context)?.let {
                Text(it, color = Lull.Muted, fontSize = 12.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        trailing()
    }
}

@Composable
private fun AddonIcon(bitmap: Bitmap?) {
    Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Lull.Chip), contentAlignment = Alignment.Center) {
        if (bitmap != null) Image(bitmap.asImageBitmap(), null, Modifier.size(32.dp))
        else Icon(Icons.Rounded.Extension, null, tint = Lull.Muted)
    }
}

// ---------------- install & permission prompts ----------------

/**
 * Questions Firefox asks while installing an extension, from the Extensions page or from
 * the "Add to Firefox" button on addons.mozilla.org.
 */
@Composable
fun ExtensionPrompts(state: BrowserState) {
    val context = LocalContext.current
    val c = context.components
    val request = state.webExtensionPromptRequest ?: return
    fun consume() { c.store.dispatch(WebExtensionAction.ConsumePromptRequestWebExtensionAction) }

    when (request) {
        is WebExtensionPromptRequest.InstallationRequested -> {
            ConfirmDialog(
                title = "Add ${request.name ?: "this extension"}?",
                text = "It will be downloaded from addons.mozilla.org.",
                confirm = "Continue",
                onConfirm = {
                    consume()
                    c.addonManager.installAddon(
                        request.url, request.installationMethod,
                        onError = { Toast.makeText(context, "Couldn't add this extension", Toast.LENGTH_SHORT).show() },
                    )
                },
                onDismiss = ::consume,
            )
        }
        is WebExtensionPromptRequest.AfterInstallation.Permissions.Required -> {
            var allowPrivate by remember(request) { mutableStateOf(false) }
            val name = request.extension.getMetadata()?.name ?: "This extension"
            AlertDialog(
                onDismissRequest = {
                    request.onConfirm(PermissionPromptResponse(isPermissionsGranted = false)); consume()
                },
                containerColor = Lull.Sheet,
                title = { Text("Add $name?", color = Lull.Text) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        val perms = request.permissions + request.origins
                        if (perms.isNotEmpty()) {
                            Text("It asks to:", color = Lull.Muted)
                            perms.take(8).forEach { Text("• ${describePermission(it)}", color = Lull.Text, fontSize = 14.sp) }
                            if (perms.size > 8) Text("…and ${perms.size - 8} more", color = Lull.Muted, fontSize = 13.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { allowPrivate = !allowPrivate }) {
                            Checkbox(checked = allowPrivate, onCheckedChange = { allowPrivate = it })
                            Text("Also run in private tabs", color = Lull.Text)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        request.onConfirm(PermissionPromptResponse(isPermissionsGranted = true, isPrivateModeGranted = allowPrivate))
                        consume()
                    }) { Text("Add") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        request.onConfirm(PermissionPromptResponse(isPermissionsGranted = false)); consume()
                    }) { Text("Cancel") }
                },
            )
        }
        is WebExtensionPromptRequest.AfterInstallation.Permissions.Optional -> {
            val name = request.extension.getMetadata()?.name ?: "An extension"
            ConfirmDialog(
                title = "$name wants more access",
                text = (request.permissions + request.origins).joinToString("\n") { "• ${describePermission(it)}" },
                confirm = "Allow",
                onConfirm = { request.onConfirm(true); consume() },
                onDismiss = { request.onConfirm(false); consume() },
            )
        }
        is WebExtensionPromptRequest.AfterInstallation.PostInstallation -> {
            LaunchedEffect(request) {
                val name = request.extension.getMetadata()?.name ?: "Extension"
                Toast.makeText(context, "$name added. Find it in the menu.", Toast.LENGTH_LONG).show()
                consume()
            }
        }
        is WebExtensionPromptRequest.BeforeInstallation.InstallationFailed -> {
            LaunchedEffect(request) {
                Toast.makeText(context, "Couldn't install this extension", Toast.LENGTH_LONG).show()
                consume()
            }
        }
        else -> LaunchedEffect(request) { consume() }
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Lull.Sheet,
        title = { Text(title, color = Lull.Text) },
        text = { Text(text, color = Lull.Muted) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Plain-language versions of the most common extension permissions. */
private fun describePermission(p: String): String = when (p) {
    "<all_urls>", "*://*/*", "http://*/*", "https://*/*" -> "Read and change your data on all websites"
    "tabs" -> "See your open tabs"
    "storage", "unlimitedStorage" -> "Store data on your device"
    "webRequest", "webRequestBlocking", "declarativeNetRequest" -> "Block or change web requests"
    "cookies" -> "Read and change cookies"
    "history" -> "Read your browsing history"
    "bookmarks" -> "Read and change bookmarks"
    "downloads" -> "Manage downloads"
    "notifications" -> "Show notifications"
    "clipboardWrite" -> "Write to your clipboard"
    "clipboardRead" -> "Read your clipboard"
    "privacy" -> "Change privacy settings"
    "nativeMessaging" -> "Talk to other apps"
    "geolocation" -> "Use your location"
    else -> if (p.contains("://") || p.startsWith("*")) "Access $p" else p
}
