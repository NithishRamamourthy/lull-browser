package app.lull.browser

import android.content.Context
import android.os.Build
import android.os.Environment
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import mozilla.appservices.fxaclient.FxaServer
import mozilla.components.browser.engine.gecko.GeckoEngine
import mozilla.components.browser.engine.gecko.autofill.GeckoAutocompleteStorageDelegate
import mozilla.components.browser.engine.gecko.fetch.GeckoViewFetchClient
import mozilla.components.browser.engine.gecko.permission.GeckoSitePermissionsStorage
import mozilla.components.browser.session.storage.SessionStorage
import mozilla.components.browser.state.engine.EngineMiddleware
import mozilla.components.browser.state.store.BrowserStore
import mozilla.components.browser.storage.sync.PlacesBookmarksStorage
import mozilla.components.browser.storage.sync.PlacesHistoryStorage
import mozilla.components.browser.storage.sync.RemoteTabsStorage
import mozilla.components.concept.base.crash.Breadcrumb
import mozilla.components.concept.base.crash.CrashReporting
import mozilla.components.concept.engine.DefaultSettings
import mozilla.components.concept.engine.Engine
import mozilla.components.concept.engine.EngineSession.TrackingProtectionPolicy
import mozilla.components.concept.sync.DeviceCapability
import mozilla.components.concept.sync.DeviceConfig
import mozilla.components.concept.sync.DeviceType
import mozilla.components.concept.sync.FxAEntryPoint
import mozilla.components.concept.sync.PeriodicSyncConfig
import mozilla.components.concept.sync.SyncConfig
import mozilla.components.concept.sync.SyncEngine
import mozilla.components.feature.accounts.FirefoxAccountsAuthFeature
import mozilla.components.feature.addons.AddonManager
import mozilla.components.feature.addons.amo.AMOAddonsProvider
import mozilla.components.feature.addons.update.DefaultAddonUpdater
import mozilla.components.feature.contextmenu.ContextMenuUseCases
import mozilla.components.feature.downloads.DefaultFileSizeFormatter
import mozilla.components.feature.downloads.DownloadEstimator
import mozilla.components.feature.downloads.DownloadMiddleware
import mozilla.components.feature.downloads.DownloadsUseCases
import mozilla.components.feature.prompts.file.FileUploadsDirCleaner
import mozilla.components.feature.session.HistoryDelegate
import mozilla.components.feature.session.SessionUseCases
import mozilla.components.feature.sitepermissions.OnDiskSitePermissionsStorage
import mozilla.components.feature.syncedtabs.storage.SyncedTabsStorage
import mozilla.components.feature.tabs.TabsUseCases
import mozilla.components.feature.webcompat.WebCompatFeature
import mozilla.components.lib.dataprotect.SecureAbove22Preferences
import mozilla.components.service.fxa.ServerConfig
import mozilla.components.service.fxa.manager.FxaAccountManager
import mozilla.components.service.fxa.sync.GlobalSyncableStoreProvider
import mozilla.components.service.sync.autofill.AutofillCreditCardsAddressesStorage
import mozilla.components.service.sync.autofill.GeckoCreditCardsAddressesStorageDelegate
import mozilla.components.service.sync.logins.GeckoLoginStorageDelegate
import mozilla.components.service.sync.logins.SyncableLoginsStorage
import mozilla.components.support.base.android.NotificationsDelegate
import mozilla.components.support.base.worker.Frequency
import mozilla.components.support.utils.DefaultDateTimeProvider
import mozilla.components.support.utils.DefaultDownloadFileUtils
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import java.util.concurrent.TimeUnit

/** Where Lull starts a Firefox Account sign-in from (reported to Mozilla's account server). */
enum class LullEntryPoint(override val entryName: String) : FxAEntryPoint {
    Menu("home-menu"),
}

/** Lull doesn't send crash reports anywhere; this satisfies libraries that ask for a reporter. */
object NoCrashReporting : CrashReporting {
    override fun submitCaughtException(throwable: Throwable): Job = Job().apply { complete() }
    override fun recordCrashBreadcrumb(breadcrumb: Breadcrumb) = Unit
}

/**
 * Every long-lived piece of the browser, created lazily. The wiring follows Mozilla's
 * reference-browser sample (MPL 2.0): https://github.com/mozilla-mobile/reference-browser
 */
class Components(private val context: Context, val scope: CoroutineScope) {

    companion object {
        /**
         * Firefox Accounts only accepts registered apps. Mozilla doesn't issue IDs to individual
         * developers, so this is the public ID of Mozilla's own reference browser, which
         * community Firefox-based browsers commonly reuse. Mozilla could block it at any time.
         */
        const val FXA_CLIENT_ID = "3c49430b43dfba77"
        const val FXA_REDIRECT_URL = "https://accounts.firefox.com/oauth/success/$FXA_CLIENT_ID"
        val SYNC_ENGINES = setOf(SyncEngine.History, SyncEngine.Bookmarks, SyncEngine.Passwords, SyncEngine.Tabs)
        private val DOWNLOADS_DIR: () -> String = {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).path
        }
    }

    val prefs by lazy { LullPrefs(context) }

    // ---------- storage ----------

    private val lazySecurePrefs = lazy { SecureAbove22Preferences(context, "lull_secure") }
    val lazyHistoryStorage = lazy { PlacesHistoryStorage(context) }
    val historyStorage by lazyHistoryStorage
    val lazyBookmarksStorage = lazy { PlacesBookmarksStorage(context) }
    val bookmarksStorage by lazyBookmarksStorage
    val lazyLoginsStorage = lazy { SyncableLoginsStorage(context, lazySecurePrefs) }
    val loginsStorage by lazyLoginsStorage
    private val lazyAutofillStorage = lazy { AutofillCreditCardsAddressesStorage(context, lazySecurePrefs) }
    val lazyRemoteTabsStorage = lazy { RemoteTabsStorage(context, NoCrashReporting) }

    // ---------- engine ----------

    /** GeckoView allows a single runtime per process; everything shares this one. */
    val runtime: GeckoRuntime by lazy {
        val settings = GeckoRuntimeSettings.Builder()
            .aboutConfigEnabled(true)
            // Lets addons.mozilla.org install extensions with its "Add to Firefox" button.
            .extensionsWebAPIEnabled(true)
            .build()
        GeckoRuntime.create(context, settings).also {
            // Fills saved passwords into login forms and offers to save new ones.
            it.setAutocompleteStorageDelegate(GeckoAutocompleteStorageDelegate(
                GeckoCreditCardsAddressesStorageDelegate(lazyAutofillStorage),
                GeckoLoginStorageDelegate(lazyLoginsStorage, isLoginAutofillEnabled = { prefs.loginAutofill }),
                scope,
            ))
        }
    }

    val engine: Engine by lazy {
        val settings = DefaultSettings(
            requestInterceptor = LullRequestInterceptor(context),
            trackingProtectionPolicy = if (prefs.strictTracking) TrackingProtectionPolicy.strict()
            else TrackingProtectionPolicy.recommended(),
            historyTrackingDelegate = HistoryDelegate(lazyHistoryStorage),
            loginAutofillEnabled = prefs.loginAutofill,
        )
        GeckoEngine(context, settings, runtime).also { WebCompatFeature.install(it) }
    }

    val client by lazy { GeckoViewFetchClient(context, runtime) }

    val notificationsDelegate by lazy { NotificationsDelegate(NotificationManagerCompat.from(context)) }
    val fileSizeFormatter by lazy { DefaultFileSizeFormatter(context) }
    val downloadEstimator by lazy { DownloadEstimator(dateTimeProvider = DefaultDateTimeProvider()) }
    val downloadFileUtils by lazy { DefaultDownloadFileUtils(context = context, downloadLocation = DOWNLOADS_DIR) }

    val store: BrowserStore by lazy {
        BrowserStore(
            middleware = listOf(
                DownloadMiddleware(
                    applicationContext = context,
                    downloadServiceClass = DownloadService::class.java,
                    deleteFileFromStorage = { false },
                    downloadFileUtils = downloadFileUtils,
                ),
            ) + EngineMiddleware.create(engine),
        )
    }

    val sessionStorage by lazy { SessionStorage(context, engine, applicationScope = scope) }

    val sessionUseCases by lazy { SessionUseCases(store) }
    val tabsUseCases by lazy { TabsUseCases(store) }
    val contextMenuUseCases by lazy { ContextMenuUseCases(store) }
    val downloadsUseCases by lazy { DownloadsUseCases(store, downloadFileUtils) }

    val sitePermissionsStorage by lazy { GeckoSitePermissionsStorage(runtime, OnDiskSitePermissionsStorage(context)) }
    val fileUploadsDirCleaner by lazy { FileUploadsDirCleaner(scope = scope) { context.cacheDir } }

    /** Workspaces, Essentials, split view and Glance: Lull's own layer over the tabs. */
    val lull by lazy { LullState(context, store, tabsUseCases, prefs) }

    // ---------- extensions ----------

    val addonUpdater by lazy {
        DefaultAddonUpdater(context, Frequency(1, TimeUnit.DAYS), notificationsDelegate = notificationsDelegate)
    }
    /** Recommended extensions come from Mozilla's curated Firefox for Android collection. */
    val addonProvider by lazy { AMOAddonsProvider(context, client, maxCacheAgeInMinutes = 24 * 60L) }
    val addonManager by lazy { AddonManager(store, engine, addonProvider, addonUpdater) }

    // ---------- Firefox Account & Sync ----------

    val accountManager: FxaAccountManager by lazy {
        GlobalSyncableStoreProvider.configureStore(SyncEngine.History to lazyHistoryStorage)
        GlobalSyncableStoreProvider.configureStore(SyncEngine.Bookmarks to lazyBookmarksStorage)
        GlobalSyncableStoreProvider.configureStore(SyncEngine.Passwords to lazyLoginsStorage)
        GlobalSyncableStoreProvider.configureStore(SyncEngine.Tabs to lazyRemoteTabsStorage)

        FxaAccountManager(
            context,
            ServerConfig(FxaServer.Release, FXA_CLIENT_ID, FXA_REDIRECT_URL),
            DeviceConfig(
                name = "Lull on ${Build.MANUFACTURER} ${Build.MODEL}",
                type = DeviceType.MOBILE,
                capabilities = setOf(DeviceCapability.SEND_TAB),
            ),
            SyncConfig(SYNC_ENGINES, PeriodicSyncConfig()),
            setOf("https://identity.mozilla.com/apps/oldsync"),
        ).also { manager -> scope.launch { manager.start() } }
    }

    /** Opens Mozilla's sign-in page in a new tab; [LullRequestInterceptor] catches the result. */
    val accountsAuthFeature by lazy {
        FirefoxAccountsAuthFeature(accountManager, FXA_REDIRECT_URL) { _, authUrl ->
            scope.launch { lull.newTab(authUrl) }
        }
    }

    val syncedTabsStorage by lazy {
        SyncedTabsStorage(accountManager, store, lazyRemoteTabsStorage.value, TimeUnit.DAYS.toMillis(14))
    }
}
