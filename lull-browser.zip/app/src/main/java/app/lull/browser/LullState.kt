package app.lull.browser

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import mozilla.components.browser.state.selector.findTab
import mozilla.components.browser.state.state.BrowserState
import mozilla.components.browser.state.state.TabSessionState
import mozilla.components.browser.state.store.BrowserStore
import mozilla.components.concept.engine.EngineSession
import mozilla.components.feature.tabs.TabsUseCases
import mozilla.components.lib.state.ext.observeForever
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

const val BLANK = "about:blank"
const val PRIVATE_WS = "private"
const val PRIVATE_COLOR = 0xFFC4A7FF

/** Search engines a workspace can use. %s is replaced by the query. */
val SEARCH_ENGINES = linkedMapOf(
    "DuckDuckGo" to "https://duckduckgo.com/?q=%s",
    "Startpage" to "https://www.startpage.com/do/search?q=%s",
    "Brave Search" to "https://search.brave.com/search?q=%s",
    "Ecosia" to "https://www.ecosia.org/search?q=%s",
    "Google" to "https://www.google.com/search?q=%s",
)

/** The four workspace colours from the design. */
val WORKSPACE_COLORS = listOf(0xFF8ED1B2, 0xFFF2B872, 0xFFA9B9FF, 0xFFF09AB8)

/** Simple settings, stored on the device. */
class LullPrefs(context: Context) {
    private val p = context.getSharedPreferences("lull", Context.MODE_PRIVATE)
    var strictTracking: Boolean
        get() = p.getBoolean("strict_tracking", true)
        set(v) = p.edit().putBoolean("strict_tracking", v).apply()
    var loginAutofill: Boolean
        get() = p.getBoolean("login_autofill", true)
        set(v) = p.edit().putBoolean("login_autofill", v).apply()
    var state: String?
        get() = p.getString("workspaces", null)
        set(v) = p.edit().putString("workspaces", v).apply()
}

class Essential(val url: String, title: String) {
    var title by mutableStateOf(title)
}

class Workspace(
    val id: String,
    name: String,
    color: Long,
    /** When on, this workspace keeps its own cookies and logins (a Firefox "container"). */
    separateLogins: Boolean,
    searchEngine: String,
) {
    var name by mutableStateOf(name)
    var color by mutableStateOf(color)
    var separateLogins by mutableStateOf(separateLogins)
    var searchEngine by mutableStateOf(searchEngine)
    val essentials = mutableStateListOf<Essential>()
    val isPrivate get() = id == PRIVATE_WS
}

/**
 * Lull's own layer over Firefox's tab list: which workspace each tab is in, pinned tabs,
 * Essentials, split view and Glance. Tabs themselves live in Mozilla's [BrowserStore].
 */
class LullState(
    context: Context,
    private val store: BrowserStore,
    private val tabsUseCases: TabsUseCases,
    private val prefs: LullPrefs,
) {
    val workspaces = mutableStateListOf<Workspace>()
    /** Private tabs are a workspace of their own that is never saved. */
    val privateWorkspace = Workspace(PRIVATE_WS, "Private", PRIVATE_COLOR, false, "DuckDuckGo")

    var currentWorkspaceId by mutableStateOf("")
        private set
    private val tabWorkspace = mutableStateMapOf<String, String>()
    private val pinned = mutableStateMapOf<String, Boolean>()
    private val lastSelected = mutableStateMapOf<String, String>()

    /** Split view: the top and bottom tab, or null. The focused pane is the store's selected tab. */
    var split by mutableStateOf<Pair<String, String>?>(null)
        private set
    var splitFraction by mutableFloatStateOf(0.5f)

    /** Glance: a link previewed in a card; not shown in tab lists until promoted. */
    var glanceTabId by mutableStateOf<String?>(null)
        private set

    /** The bottom bar shrinks to a pill while scrolling down. */
    var compactBar by mutableStateOf(false)

    /** An extension whose toolbar pop-up is open. */
    var popupExtensionId by mutableStateOf<String?>(null)

    private var restored = false
    private val pendingUrls = mutableListOf<String>()

    init {
        load()
        if (workspaces.isEmpty()) {
            workspaces += Workspace(newId(), "Personal", WORKSPACE_COLORS[0], false, "DuckDuckGo")
            workspaces += Workspace(newId(), "Work", WORKSPACE_COLORS[1], true, "DuckDuckGo")
        }
        if (workspace(currentWorkspaceId) == null) currentWorkspaceId = workspaces.first().id
        store.observeForever { onStoreChanged(it) }
    }

    // ---------- lookups ----------

    val currentWorkspace: Workspace get() = workspace(currentWorkspaceId) ?: workspaces.first()

    fun workspace(id: String?): Workspace? =
        if (id == PRIVATE_WS) privateWorkspace else workspaces.firstOrNull { it.id == id }

    fun contextIdFor(ws: Workspace): String? = if (ws.separateLogins && !ws.isPrivate) "lull-${ws.id}" else null

    fun workspaceOf(tab: TabSessionState): String {
        if (tab.content.private) return PRIVATE_WS
        tabWorkspace[tab.id]?.let { if (workspace(it) != null) return it }
        tab.parentId?.let { parent -> tabWorkspace[parent]?.let { return it } }
        workspaces.firstOrNull { tab.contextId != null && contextIdFor(it) == tab.contextId }?.let { return it.id }
        return currentWorkspaceId
    }

    fun tabsIn(state: BrowserState, wsId: String): List<TabSessionState> =
        state.tabs.filter { it.id != glanceTabId && workspaceOf(it) == wsId }
            .sortedByDescending { pinned[it.id] == true }

    fun isPinned(tabId: String) = pinned[tabId] == true

    fun togglePin(tabId: String) {
        if (isPinned(tabId)) pinned.remove(tabId) else pinned[tabId] = true
        persist()
    }

    // ---------- tabs ----------

    fun newTab(url: String = BLANK, wsId: String = currentWorkspaceId, select: Boolean = true, parentId: String? = null): String {
        val ws = workspace(wsId) ?: currentWorkspace
        val id = tabsUseCases.addTab(
            url = url,
            selectTab = select,
            parentId = parentId,
            contextId = contextIdFor(ws),
            private = ws.isPrivate,
        )
        tabWorkspace[id] = ws.id
        if (select) {
            currentWorkspaceId = ws.id
            if (split != null && split?.toList()?.contains(id) != true) split = null
        }
        persist()
        return id
    }

    /** Tabs that extensions open go to the workspace you're in. */
    fun newTabForExtension(url: String, engineSession: EngineSession, select: Boolean, private: Boolean): String {
        val id = tabsUseCases.addTab(url = url, selectTab = select, engineSession = engineSession, private = private)
        tabWorkspace[id] = if (private) PRIVATE_WS else currentWorkspaceId
        persist()
        return id
    }

    /** Selects a tab. In split view it replaces the tab in the focused pane. */
    fun select(tabId: String) {
        val state = store.state
        val tab = state.findTab(tabId) ?: return
        val s = split
        if (s != null && tabId !in s.toList()) {
            split = if (workspaceOf(tab) != currentWorkspaceId) null
            else if (state.selectedTabId == s.first) s.copy(first = tabId) else s.copy(second = tabId)
        }
        tabsUseCases.selectTab(tabId)
        compactBar = false
    }

    fun closeTab(tabId: String) {
        val state = store.state
        val tab = state.findTab(tabId) ?: return
        val wsId = workspaceOf(tab)
        if (split?.toList()?.contains(tabId) == true) split = null
        if (state.selectedTabId == tabId) {
            // Stay in the same workspace: Firefox would otherwise pick a tab from any workspace.
            val list = tabsIn(state, wsId)
            val i = list.indexOfFirst { it.id == tabId }
            val fallback = tab.parentId?.takeIf { p -> list.any { it.id == p } }
                ?: list.getOrNull(i + 1)?.id ?: list.getOrNull(i - 1)?.id
            if (fallback != null) tabsUseCases.selectTab(fallback) else newTab(BLANK, wsId)
        }
        tabsUseCases.removeTab(tabId)
        tabWorkspace.remove(tabId)
        pinned.remove(tabId)
        persist()
    }

    fun closeUnpinned(wsId: String) {
        tabsIn(store.state, wsId).filter { !isPinned(it.id) }.forEach { closeTab(it.id) }
    }

    /** Turns typed text into a URL, or a search with the workspace's engine. */
    fun resolveInput(raw: String): String {
        val text = raw.trim()
        if (text.isEmpty()) return BLANK
        val schemes = listOf("http:", "https:", "about:", "file:", "data:", "view-source:", "moz-extension:")
        if (schemes.any { text.startsWith(it, ignoreCase = true) }) return text
        val looksLikeHost = !text.contains(' ') &&
            (text.contains('.') || text.startsWith("localhost")) && !text.endsWith('.')
        if (looksLikeHost) return "https://$text"
        val template = SEARCH_ENGINES[currentWorkspace.searchEngine] ?: SEARCH_ENGINES.values.first()
        return template.replace("%s", Uri.encode(text))
    }

    // ---------- workspaces ----------

    fun switchWorkspace(id: String) {
        if (workspace(id) == null) return
        split = null
        currentWorkspaceId = id
        val state = store.state
        val list = tabsIn(state, id)
        val target = lastSelected[id]?.takeIf { t -> list.any { it.id == t } } ?: list.firstOrNull()?.id
        if (target != null) tabsUseCases.selectTab(target) else newTab(BLANK, id)
        persist()
    }

    /** Swipe on the bar: +1 next workspace, -1 previous. */
    fun switchWorkspaceBy(delta: Int) {
        val i = workspaces.indexOfFirst { it.id == currentWorkspaceId }
        workspaces.getOrNull(i + delta)?.let { switchWorkspace(it.id) }
    }

    fun addWorkspace(): Workspace {
        val n = workspaces.size
        val ws = Workspace(newId(), "Workspace ${n + 1}", WORKSPACE_COLORS[n % WORKSPACE_COLORS.size], false, "DuckDuckGo")
        workspaces += ws
        persist()
        return ws
    }

    fun deleteWorkspace(ws: Workspace) {
        if (workspaces.size <= 1 || ws.isPrivate) return
        val ids = tabsIn(store.state, ws.id).map { it.id }
        workspaces.remove(ws)
        if (currentWorkspaceId == ws.id) switchWorkspace(workspaces.first().id)
        tabsUseCases.removeTabs(ids)
        ids.forEach { tabWorkspace.remove(it); pinned.remove(it) }
        persist()
    }

    // ---------- Essentials ----------

    fun isEssential(url: String) = currentWorkspace.essentials.any { it.url == url }

    fun toggleEssential(url: String, title: String) {
        val ws = currentWorkspace
        if (ws.isPrivate || url == BLANK) return
        val existing = ws.essentials.firstOrNull { it.url == url }
        if (existing != null) ws.essentials.remove(existing) else ws.essentials += Essential(url, title)
        persist()
    }

    fun removeEssential(e: Essential) {
        currentWorkspace.essentials.remove(e)
        persist()
    }

    /** An Essential reuses an open tab on the same site instead of piling up copies. */
    fun openEssential(e: Essential) {
        val host = Uri.parse(e.url).host
        val existing = tabsIn(store.state, currentWorkspaceId).firstOrNull { Uri.parse(it.content.url).host == host }
        if (existing != null) select(existing.id) else newTab(e.url)
    }

    // ---------- split view ----------

    fun enterSplit(secondId: String? = null) {
        val state = store.state
        val first = state.selectedTabId ?: return
        val other = secondId?.takeIf { it != first }
            ?: tabsIn(state, currentWorkspaceId).firstOrNull { it.id != first }?.id
            ?: newTab(BLANK, select = false)
        split = first to other
        splitFraction = 0.5f
        tabsUseCases.selectTab(other)
    }

    fun exitSplit() { split = null }

    fun swapSplit() { split = split?.let { it.second to it.first } }

    fun focusPane(tabId: String) {
        if (store.state.selectedTabId != tabId) tabsUseCases.selectTab(tabId)
    }

    // ---------- Glance ----------

    fun openGlance(url: String) {
        closeGlance()
        val ws = currentWorkspace
        glanceTabId = tabsUseCases.addTab(
            url = url,
            selectTab = false,
            parentId = store.state.selectedTabId,
            contextId = contextIdFor(ws),
            private = ws.isPrivate,
        )
    }

    fun closeGlance() {
        glanceTabId?.let { tabsUseCases.removeTab(it) }
        glanceTabId = null
    }

    fun glanceToTab() {
        val id = glanceTabId ?: return
        glanceTabId = null
        tabWorkspace[id] = currentWorkspaceId
        select(id)
        persist()
    }

    fun glanceToSplit() {
        val id = glanceTabId ?: return
        glanceTabId = null
        tabWorkspace[id] = currentWorkspaceId
        enterSplit(id)
        persist()
    }

    // ---------- keeping in step with Firefox's tab list ----------

    private fun onStoreChanged(state: BrowserState) {
        // New tabs from links, pop-ups or extensions: file them under a workspace.
        state.tabs.forEach { tab ->
            if (tab.id != glanceTabId && !tab.content.private && tab.id !in tabWorkspace) {
                tabWorkspace[tab.id] = workspaceOf(tab)
            }
        }
        val selected = state.selectedTabId?.let { state.findTab(it) }
        if (selected != null && selected.id != glanceTabId) {
            val ws = workspaceOf(selected)
            if (ws != currentWorkspaceId) {
                currentWorkspaceId = ws
                split = null
            }
            lastSelected[ws] = selected.id
        }
        val ids = state.tabs.map { it.id }.toSet()
        split?.let { if (it.first !in ids || it.second !in ids) split = null }
        glanceTabId?.let { if (it !in ids) glanceTabId = null }
        if (restored) {
            tabWorkspace.keys.filter { it !in ids }.forEach { tabWorkspace.remove(it) }
            pinned.keys.filter { it !in ids }.forEach { pinned.remove(it) }
        }
    }

    /** Links from other apps wait until saved tabs are back, so they don't get replaced. */
    fun openFromOutside(url: String) {
        if (restored) newTab(url) else pendingUrls += url
    }

    fun onTabsRestored() {
        restored = true
        pendingUrls.forEach { newTab(it) }
        pendingUrls.clear()
        val state = store.state
        if (tabsIn(state, currentWorkspaceId).isEmpty()) {
            newTab()
        } else if (state.selectedTabId == null || state.findTab(state.selectedTabId!!)?.let(::workspaceOf) != currentWorkspaceId) {
            switchWorkspace(currentWorkspaceId)
        }
    }

    // ---------- saving ----------

    fun persist() {
        val root = JSONObject()
        root.put("current", if (currentWorkspaceId == PRIVATE_WS) workspaces.first().id else currentWorkspaceId)
        root.put("workspaces", JSONArray().apply {
            workspaces.forEach { ws ->
                put(JSONObject().apply {
                    put("id", ws.id); put("name", ws.name); put("color", ws.color)
                    put("separate", ws.separateLogins); put("search", ws.searchEngine)
                    put("essentials", JSONArray().apply {
                        ws.essentials.forEach { put(JSONObject().put("url", it.url).put("title", it.title)) }
                    })
                })
            }
        })
        root.put("tabs", JSONObject().apply { tabWorkspace.forEach { (t, w) -> if (w != PRIVATE_WS) put(t, w) } })
        root.put("pinned", JSONArray().apply { pinned.keys.forEach { put(it) } })
        root.put("selected", JSONObject().apply { lastSelected.forEach { (w, t) -> put(w, t) } })
        prefs.state = root.toString()
    }

    private fun load() {
        val raw = prefs.state ?: return
        try {
            val root = JSONObject(raw)
            val arr = root.getJSONArray("workspaces")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ws = Workspace(
                    o.getString("id"), o.getString("name"), o.getLong("color"),
                    o.optBoolean("separate"), o.optString("search", "DuckDuckGo"),
                )
                val es = o.optJSONArray("essentials") ?: JSONArray()
                for (j in 0 until es.length()) {
                    val e = es.getJSONObject(j)
                    ws.essentials += Essential(e.getString("url"), e.optString("title"))
                }
                workspaces += ws
            }
            currentWorkspaceId = root.optString("current")
            root.optJSONObject("tabs")?.let { t -> t.keys().forEach { tabWorkspace[it] = t.getString(it) } }
            root.optJSONArray("pinned")?.let { p -> for (i in 0 until p.length()) pinned[p.getString(i)] = true }
            root.optJSONObject("selected")?.let { s -> s.keys().forEach { lastSelected[it] = s.getString(it) } }
        } catch (e: Exception) {
            workspaces.clear()
        }
    }

    private fun newId() = UUID.randomUUID().toString()
}

fun hostOf(url: String): String =
    if (url == BLANK || url.isBlank()) "" else Uri.parse(url).host?.removePrefix("www.") ?: url
