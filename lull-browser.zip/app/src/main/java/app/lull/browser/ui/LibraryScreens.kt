package app.lull.browser.ui

import android.content.Intent
import android.provider.Settings
import android.text.format.DateUtils
import android.widget.Toast
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import app.lull.browser.LullState
import app.lull.browser.components
import app.lull.browser.hostOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import mozilla.components.concept.storage.BookmarkNode
import mozilla.components.concept.storage.BookmarkNodeType
import mozilla.components.concept.storage.Login
import mozilla.components.concept.storage.VisitInfo
import mozilla.components.concept.storage.VisitType

// ---------------- bookmarks ----------------

private data class BookmarkRow(val node: BookmarkNode, val folder: String)

private fun flatten(node: BookmarkNode, folder: String, out: MutableList<BookmarkRow>) {
    node.children?.forEach { child ->
        when (child.type) {
            BookmarkNodeType.ITEM -> if (child.url != null) out += BookmarkRow(child, folder)
            BookmarkNodeType.FOLDER -> flatten(child, child.title?.takeIf { it.isNotBlank() } ?: folder, out)
            else -> Unit
        }
    }
}

/** Bookmarks from this phone and, when signed in, from Firefox on your other devices. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BookmarksScreen(lull: LullState, onDone: () -> Unit) {
    val c = LocalContext.current.components
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<BookmarkRow>?>(null) }
    var query by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) {
        rows = withContext(Dispatchers.IO) {
            val out = mutableListOf<BookmarkRow>()
            c.bookmarksStorage.getTree("root________", true).getOrNull()?.let { flatten(it, "Bookmarks", out) }
            out
        }
    }
    FullScreenPage {
        ScreenHeader("Bookmarks", onDone)
        SearchField(query, "Search bookmarks") { query = it }
        val list = rows?.filter {
            query.isBlank() || (it.node.title ?: "").contains(query, true) || (it.node.url ?: "").contains(query, true)
        }
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> EmptyNote("No bookmarks yet. Tap Bookmark in the menu to save a page.")
            else -> LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                list.groupBy { it.folder }.forEach { (folder, items) ->
                    item(key = "f$folder") {
                        Row(Modifier.padding(start = 8.dp, top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Folder, null, tint = Lull.Muted, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            SectionLabel(folder)
                        }
                    }
                    items(items, key = { it.node.guid }) { row ->
                        val url = row.node.url!!
                        LibraryRow(
                            url, row.node.title?.ifBlank { null } ?: hostOf(url), hostOf(url),
                            onClick = { lull.newTab(url); onDone() },
                            onDelete = {
                                scope.launch {
                                    withContext(Dispatchers.IO) { c.bookmarksStorage.deleteNode(row.node.guid) }
                                    reload++
                                }
                            },
                        )
                    }
                }
            }
        }
    }
}

// ---------------- history ----------------

@Composable
fun HistoryScreen(lull: LullState, onDone: () -> Unit) {
    val context = LocalContext.current
    val c = context.components
    val scope = rememberCoroutineScope()
    var visits by remember { mutableStateOf<List<VisitInfo>?>(null) }
    var query by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    var confirmClear by remember { mutableStateOf(false) }
    LaunchedEffect(reload) {
        visits = withContext(Dispatchers.IO) {
            c.historyStorage.getVisitsPaginated(
                0L, 500L,
                excludeTypes = listOf(
                    VisitType.REDIRECT_PERMANENT, VisitType.REDIRECT_TEMPORARY, VisitType.EMBED,
                    VisitType.FRAMED_LINK, VisitType.RELOAD, VisitType.DOWNLOAD,
                ),
            ).distinctBy { it.url }
        }
    }
    FullScreenPage {
        ScreenHeader("History", onDone) {
            TextButton(onClick = { confirmClear = true }) { Text("Clear all", color = Lull.Muted) }
        }
        SearchField(query, "Search history") { query = it }
        val list = visits?.filter { query.isBlank() || (it.title ?: "").contains(query, true) || it.url.contains(query, true) }
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> EmptyNote("No history yet.")
            else -> LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                list.groupBy { dayLabel(context, it.visitTime) }.forEach { (day, items) ->
                    item(key = "d$day") { Box(Modifier.padding(start = 8.dp, top = 14.dp, bottom = 6.dp)) { SectionLabel(day) } }
                    items(items, key = { it.url + it.visitTime }) { v ->
                        LibraryRow(
                            v.url, v.title?.ifBlank { null } ?: hostOf(v.url), hostOf(v.url),
                            onClick = { lull.newTab(v.url); onDone() },
                            onDelete = {
                                scope.launch {
                                    withContext(Dispatchers.IO) { c.historyStorage.deleteVisitsFor(v.url) }
                                    reload++
                                }
                            },
                        )
                    }
                }
            }
        }
    }
    if (confirmClear) {
        ConfirmDialog(
            title = "Clear all history?",
            text = "This removes your browsing history from this phone. If you sync, it's also removed from your other devices.",
            confirm = "Clear",
            onConfirm = {
                confirmClear = false
                scope.launch {
                    withContext(Dispatchers.IO) { c.historyStorage.deleteEverything() }
                    reload++
                }
            },
            onDismiss = { confirmClear = false },
        )
    }
}

private fun dayLabel(context: android.content.Context, time: Long): String = when {
    DateUtils.isToday(time) -> "Today"
    DateUtils.isToday(time + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    else -> DateUtils.formatDateTime(context, time, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_MONTH)
}

// ---------------- passwords ----------------

/** Saved passwords, unlocked with your fingerprint, face or screen lock. */
@Composable
fun PasswordsScreen(onDone: () -> Unit) {
    val context = LocalContext.current
    val c = context.components
    val scope = rememberCoroutineScope()
    var unlocked by remember { mutableStateOf(false) }
    var logins by remember { mutableStateOf<List<Login>?>(null) }
    var query by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }

    fun unlock() {
        val activity = context as? FragmentActivity ?: return
        val prompt = BiometricPrompt(
            activity, ContextCompat.getMainExecutor(context),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { unlocked = true }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    Toast.makeText(context, errString, Toast.LENGTH_SHORT).show()
                }
            },
        )
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock saved passwords")
                .setAllowedAuthenticators(BIOMETRIC_WEAK or DEVICE_CREDENTIAL)
                .build(),
        )
    }
    LaunchedEffect(Unit) { unlock() }
    LaunchedEffect(unlocked, reload) {
        if (unlocked) logins = withContext(Dispatchers.IO) { c.loginsStorage.list() }.sortedBy { hostOf(it.origin) }
    }

    FullScreenPage {
        ScreenHeader("Passwords", onDone)
        if (!unlocked) {
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Your saved passwords are locked.", color = Lull.Muted)
                Spacer(Modifier.height(12.dp))
                Button(onClick = ::unlock) { Text("Unlock") }
            }
            return@FullScreenPage
        }
        SearchField(query, "Search passwords") { query = it }
        val list = logins?.filter { query.isBlank() || it.origin.contains(query, true) || it.username.contains(query, true) }
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> EmptyNote("No saved passwords. Lull offers to save them when you sign in to a site.")
            else -> LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(list, key = { it.guid }) { login ->
                    LoginRow(login, onDelete = {
                        scope.launch {
                            withContext(Dispatchers.IO) { c.loginsStorage.delete(login.guid) }
                            reload++
                        }
                    })
                }
            }
        }
    }
}

@Composable
private fun LoginRow(login: Login, onDelete: () -> Unit) {
    val context = LocalContext.current
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Lull.Bar).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Monogram(login.origin, 32)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(hostOf(login.origin).ifEmpty { login.origin }, color = Lull.Text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(login.username.ifEmpty { "(no username)" }, color = Lull.Muted, fontSize = 13.sp, maxLines = 1)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, "Delete password", tint = Lull.Muted) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (show) login.password else "••••••••••", color = Lull.Text,
                fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f).padding(start = 44.dp),
            )
            IconButton(onClick = { show = !show }) {
                Icon(if (show) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, if (show) "Hide password" else "Show password", tint = Lull.Muted)
            }
            IconButton(onClick = { copyText(context, login.password, "Password copied") }) {
                Icon(Icons.Rounded.ContentCopy, "Copy password", tint = Lull.Muted)
            }
        }
    }
}

// ---------------- settings ----------------

@Composable
fun SettingsScreen(onDone: () -> Unit) {
    val context = LocalContext.current
    val c = context.components
    var strict by remember { mutableStateOf(c.prefs.strictTracking) }
    var autofill by remember { mutableStateOf(c.prefs.loginAutofill) }
    FullScreenPage {
        ScreenHeader("Settings", onDone)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleRow(
                "Strict tracking protection",
                "Blocks more trackers and fingerprinting. A few sites may not work properly. Takes effect after restarting Lull.",
                strict,
            ) { strict = it; c.prefs.strictTracking = it }
            ToggleRow("Save and fill passwords", "Offer to save logins and fill them in automatically.", autofill) {
                autofill = it; c.prefs.loginAutofill = it
            }
            SettingsLink("Make Lull your default browser") {
                context.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            SettingsLink("Advanced (about:config)") { c.lull.newTab("about:config"); onDone() }
            Text(
                "Lull is built on Firefox's engine (GeckoView) and Mozilla Android Components, released under the Mozilla Public License 2.0.",
                color = Lull.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 16.dp),
            )
        }
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Lull.Bar).clickable { onChange(!checked) }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Lull.Text, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Lull.Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SettingsLink(title: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Lull.Bar).clickable(onClick = onClick).padding(16.dp),
    ) { Text(title, color = Lull.Text, fontWeight = FontWeight.Bold) }
}

// ---------------- shared bits ----------------

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LibraryRow(url: String, title: String, subtitle: String, onClick: () -> Unit, onDelete: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 58.dp).clip(RoundedCornerShape(16.dp))
            .combinedClickable(onClick = onClick, onLongClick = onDelete, onLongClickLabel = "Delete")
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Monogram(url, 32)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Lull.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Lull.Muted, fontSize = 12.5.sp, maxLines = 1)
        }
        IconButton(onClick = onDelete) { Icon(Icons.Rounded.Close, "Delete", tint = Lull.Faint, modifier = Modifier.size(18.dp)) }
    }
}

@Composable
private fun SearchField(value: String, placeholder: String, onChange: (String) -> Unit) {
    TextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text(placeholder, color = Lull.Muted) },
        shape = RoundedCornerShape(16.dp), colors = lullFieldColors(Lull.Text),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

@Composable
private fun EmptyNote(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Lull.Muted, fontSize = 15.sp)
    }
}
