package app.lull.browser.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.ViewAgenda
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.lull.browser.BLANK
import app.lull.browser.LullState
import app.lull.browser.components
import app.lull.browser.hostOf
import mozilla.components.browser.state.action.ContentAction
import mozilla.components.browser.state.selector.findTab
import mozilla.components.browser.state.selector.selectedTab
import mozilla.components.browser.state.state.BrowserState
import mozilla.components.browser.state.state.SecurityInfo
import mozilla.components.browser.state.state.TabSessionState
import mozilla.components.concept.engine.EngineSession
import mozilla.components.concept.engine.HitResult
import mozilla.components.lib.state.ext.observeAsComposableState
import kotlin.math.abs

/** Full-screen pages that open over the browser. */
enum class Screen { None, Workspaces, Extensions, Account, Bookmarks, History, Passwords, Settings }

/** A long-press on something that isn't a plain link (images, video, phone numbers…). */
data class ContextTarget(val tabId: String, val hit: HitResult, val private: Boolean)

@Composable
fun BrowserScreen(onFullScreen: (Boolean) -> Unit, onExit: () -> Unit, consumeBack: () -> Boolean) {
    val c = LocalContext.current.components
    val lull = c.lull
    val state by c.store.observeAsComposableState { it }
    val selected = state.selectedTab?.takeIf { it.id != lull.glanceTabId }
    val accent = Color(lull.currentWorkspace.color)

    var editing by remember { mutableStateOf(false) }
    var tabSheet by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var finding by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf(Screen.None) }
    var contextTarget by remember { mutableStateOf<ContextTarget?>(null) }

    val fullScreen = selected?.content?.fullScreen == true
    LaunchedEffect(fullScreen) { onFullScreen(fullScreen) }

    // Shrink the bar while scrolling down.
    ScrollWatcher(selected?.engineState?.engineSession, lull)

    // Long-press: links open in Glance; anything else gets a small action sheet.
    LaunchedEffect(selected?.id, selected?.content?.hitResult) {
        val tab = selected ?: return@LaunchedEffect
        val hit = tab.content.hitResult ?: return@LaunchedEffect
        c.store.dispatch(ContentAction.ConsumeHitResultAction(tab.id))
        val link = when (hit) {
            is HitResult.IMAGE_SRC -> hit.uri
            is HitResult.UNKNOWN -> hit.src.takeIf { it.startsWith("http") }
            else -> null
        }
        if (link != null) lull.openGlance(link) else contextTarget = ContextTarget(tab.id, hit, tab.content.private)
    }

    BackHandler {
        when {
            lull.popupExtensionId != null -> lull.popupExtensionId = null
            lull.glanceTabId != null -> lull.closeGlance()
            screen != Screen.None -> screen = Screen.None
            editing -> editing = false
            finding -> finding = false
            consumeBack() -> Unit
            fullScreen -> c.sessionUseCases.exitFullscreen(selected?.id)
            selected != null && selected.content.canGoBack -> c.sessionUseCases.goBack(selected.id)
            selected?.parentId != null && state.findTab(selected.parentId!!) != null -> lull.closeTab(selected.id)
            lull.split != null -> lull.exitSplit()
            else -> onExit()
        }
    }

    Box(Modifier.fillMaxSize().background(Lull.Bg)) {
        Column(
            Modifier
                .fillMaxSize()
                .then(if (fullScreen) Modifier else Modifier.systemBarsPadding().imePadding())
                .padding(if (fullScreen) 0.dp else 10.dp),
            verticalArrangement = Arrangement.spacedBy(if (fullScreen) 0.dp else 8.dp),
        ) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                ContentArea(state, lull, selected, accent, fullScreen, onSearch = { editing = true })
            }
            if (finding && selected != null) {
                FindBar(selected, accent, onClose = { finding = false })
            } else if (!fullScreen) {
                AnimatedContent(targetState = lull.compactBar, label = "bar") { compact ->
                    if (compact) {
                        CompactBar(lull, selected) { lull.compactBar = false }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            WorkspaceDots(lull, state)
                            MainBar(
                                lull, state, selected, accent,
                                onAddress = { editing = true },
                                onTabs = { tabSheet = true },
                                onMenu = { menu = true },
                            )
                        }
                    }
                }
            }
        }

        lull.glanceTabId?.let { Glance(it, state, lull, accent) }

        if (editing) AddressEditor(lull, selected, accent, onDone = { editing = false })

        if (tabSheet) {
            TabSheet(
                state, lull, accent,
                onDismiss = { tabSheet = false },
                onNewTab = { tabSheet = false; lull.newTab(); editing = true },
                onManageWorkspaces = { tabSheet = false; screen = Screen.Workspaces },
            )
        }
        if (menu) {
            MenuSheet(
                state, lull, selected, accent,
                onDismiss = { menu = false },
                onFind = { menu = false; finding = true },
                onOpen = { menu = false; screen = it },
            )
        }
        contextTarget?.let { ContextSheet(it, lull, onDismiss = { contextTarget = null }) }
        lull.popupExtensionId?.let { ExtensionPopup(it, state, lull) }
        ExtensionPrompts(state)

        AnimatedVisibility(visible = screen != Screen.None) {
            val close = { screen = Screen.None }
            when (screen) {
                Screen.Workspaces -> WorkspacesScreen(lull, state, onDone = close)
                Screen.Extensions -> ExtensionsScreen(lull, onDone = close)
                Screen.Account -> AccountScreen(lull, onDone = close)
                Screen.Bookmarks -> BookmarksScreen(lull, onDone = close)
                Screen.History -> HistoryScreen(lull, onDone = close)
                Screen.Passwords -> PasswordsScreen(onDone = close)
                Screen.Settings -> SettingsScreen(onDone = close)
                Screen.None -> Unit
            }
        }
    }
}

@Composable
private fun ScrollWatcher(session: EngineSession?, lull: LullState) {
    DisposableEffect(session) {
        var lastY = 0
        val observer = object : EngineSession.Observer {
            override fun onScrollChange(scrollX: Int, scrollY: Int) {
                val dy = scrollY - lastY
                if (scrollY < 48 || dy < -24) lull.compactBar = false
                else if (dy > 24) lull.compactBar = true
                if (abs(dy) > 24 || scrollY < 48) lastY = scrollY
            }
        }
        session?.register(observer)
        onDispose { session?.unregister(observer) }
    }
}

// ---------------- page area ----------------

@Composable
private fun ContentArea(
    state: BrowserState,
    lull: LullState,
    selected: TabSessionState?,
    accent: Color,
    fullScreen: Boolean,
    onSearch: () -> Unit,
) {
    val split = lull.split
    val top = split?.first?.let { state.findTab(it) }
    val bottom = split?.second?.let { state.findTab(it) }
    if (top == null || bottom == null) {
        if (selected == null) StartPage(lull, null, accent, onSearch)
        else Pane(lull, selected, accent, focused = false, radius = if (fullScreen) 0 else 22, onSearch, Modifier.fillMaxSize())
        return
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val total = constraints.maxHeight.toFloat()
        Column(Modifier.fillMaxSize()) {
            Pane(lull, top, accent, state.selectedTabId == top.id, 20, onSearch, Modifier.weight(lull.splitFraction).fillMaxWidth())
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(22.dp)
                    .semantics { contentDescription = "Resize panes. Drag up or down" }
                    .pointerInput(total) {
                        detectVerticalDragGestures { change, dy ->
                            change.consume()
                            lull.splitFraction = (lull.splitFraction + dy / total).coerceIn(0.2f, 0.8f)
                        }
                    },
                contentAlignment = Alignment.Center,
            ) { Box(Modifier.size(48.dp, 5.dp).clip(CircleShape).background(Color(0xFF6A6870))) }
            Pane(lull, bottom, accent, state.selectedTabId == bottom.id, 20, onSearch, Modifier.weight(1f - lull.splitFraction).fillMaxWidth())
        }
    }
}

@Composable
private fun Pane(
    lull: LullState,
    tab: TabSessionState,
    accent: Color,
    focused: Boolean,
    radius: Int,
    onSearch: () -> Unit,
    modifier: Modifier,
) {
    Box(
        modifier
            .then(if (focused) Modifier.border(3.dp, accent, RoundedCornerShape(radius.dp)).padding(3.dp) else Modifier)
            .pointerInput(tab.id) {
                // Touching a split pane focuses it, without stealing the touch from the page.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    if (lull.split != null) lull.focusPane(tab.id)
                }
            },
    ) {
        EnginePane(tab.id, Modifier.fillMaxSize())
        if (tab.content.url == BLANK && !tab.content.loading) StartPage(lull, tab, accent, onSearch)
        if (radius > 0) CornerMask((if (focused) radius - 3 else radius).dp, Lull.Bg)
        if (tab.content.loading && tab.content.progress in 1..99) {
            LinearProgressIndicator(
                progress = { tab.content.progress / 100f },
                modifier = Modifier.fillMaxWidth().height(3.dp).align(Alignment.TopCenter),
                color = accent,
                trackColor = Color.Transparent,
            )
        }
    }
}

/** What a new tab shows: a search field and this workspace's Essentials. */
@Composable
private fun StartPage(lull: LullState, tab: TabSessionState?, accent: Color, onSearch: () -> Unit) {
    val c = LocalContext.current.components
    val ws = lull.currentWorkspace
    Column(
        Modifier.fillMaxSize().clip(RoundedCornerShape(22.dp)).background(Color(0xFF1C1B21)).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (ws.isPrivate) {
            Icon(Icons.Rounded.VisibilityOff, null, tint = accent, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(10.dp))
            Text(
                "Private tab: no history, cookies or form data are kept after you close it.",
                color = Lull.Muted, fontSize = 14.sp,
            )
        } else {
            Text(ws.name, color = Lull.Muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(18.dp)).background(Lull.Field)
                .clickable(onClick = onSearch).padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Search, null, tint = accent)
            Spacer(Modifier.width(12.dp))
            Text("Search or enter address", color = Lull.Muted, fontSize = 16.sp)
        }
        if (ws.essentials.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            EssentialsGrid(lull, onOpen = { e ->
                if (tab != null) c.sessionUseCases.loadUrl(e.url, tab.id) else lull.openEssential(e)
            })
        }
    }
}

// ---------------- bottom bar ----------------

@Composable
private fun WorkspaceDots(lull: LullState, state: BrowserState) {
    val hasPrivate = lull.tabsIn(state, app.lull.browser.PRIVATE_WS).isNotEmpty()
    Row(
        Modifier.fillMaxWidth().height(24.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val list = lull.workspaces + if (hasPrivate) listOf(lull.privateWorkspace) else emptyList()
        list.forEach { ws ->
            val current = ws.id == lull.currentWorkspaceId
            val w by animateDpAsState(if (current) 22.dp else 6.dp, label = "dot")
            Box(
                Modifier.size(28.dp, 24.dp).clickable { lull.switchWorkspace(ws.id) }
                    .semantics { contentDescription = "Switch to ${ws.name}" },
                contentAlignment = Alignment.Center,
            ) { Box(Modifier.size(w, 6.dp).clip(CircleShape).background(Color(ws.color))) }
        }
        Spacer(Modifier.width(4.dp))
        Text(lull.currentWorkspace.name, color = Lull.Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun MainBar(
    lull: LullState,
    state: BrowserState,
    tab: TabSessionState?,
    accent: Color,
    onAddress: () -> Unit,
    onTabs: () -> Unit,
    onMenu: () -> Unit,
) {
    val c = LocalContext.current.components
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val tabCount = lull.tabsIn(state, lull.currentWorkspaceId).size
    val canGoBack = tab?.content?.canGoBack == true

    Row(
        Modifier
            .fillMaxWidth()
            .height(60.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Lull.Bar)
            // Swipe sideways: change workspace. Swipe up: open tabs.
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { dragX = 0f; dragY = 0f },
                    onDragEnd = {
                        when {
                            dragY < -80 && abs(dragY) > abs(dragX) -> onTabs()
                            abs(dragX) > 120 -> lull.switchWorkspaceBy(if (dragX < 0) 1 else -1)
                        }
                    },
                ) { change, amount ->
                    change.consume()
                    dragX += amount.x
                    dragY += amount.y
                }
            }
            .padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        IconButton(onClick = { c.sessionUseCases.goBack(tab?.id) }, enabled = canGoBack, modifier = Modifier.size(48.dp)) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = if (canGoBack) Lull.Text else Lull.Faint)
        }
        Row(
            Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(16.dp)).background(Lull.Field)
                .clickable(onClick = onAddress).padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val url = tab?.content?.url ?: BLANK
            when {
                url == BLANK -> Unit
                tab?.content?.securityInfo is SecurityInfo.Secure ->
                    Icon(Icons.Rounded.Lock, "Secure connection", tint = Lull.Text, modifier = Modifier.size(16.dp))
                url.startsWith("http:") ->
                    Icon(Icons.Rounded.LockOpen, "Not secure", tint = Color(0xFFF2B872), modifier = Modifier.size(16.dp))
            }
            if (url != BLANK) Spacer(Modifier.width(8.dp))
            Text(
                if (url == BLANK) "Search or enter address" else hostOf(url).ifEmpty { url },
                color = if (url == BLANK) Lull.Muted else Lull.Text,
                fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            if (lull.split != null) {
                IconButton(onClick = { lull.swapSplit() }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Rounded.SwapVert, "Swap panes", tint = Lull.Muted)
                }
            } else {
                val blocked = tab?.trackingProtection?.blockedTrackers?.size ?: 0
                Icon(
                    Icons.Rounded.Shield,
                    if (blocked > 0) "Tracking protection on, $blocked blocked" else "Tracking protection on",
                    tint = accent, modifier = Modifier.size(18.dp),
                )
            }
        }
        if (lull.split != null) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(accent).clickable { lull.exitSplit() }
                    .semantics { contentDescription = "Exit split view" },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.ViewAgenda, null, tint = Lull.OnAccent) }
        }
        Box(
            Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onTabs)
                .semantics { contentDescription = "$tabCount tabs. Open tab sheet" },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(24.dp).border(2.dp, Lull.Text, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                Text(if (tabCount > 99) "∞" else "$tabCount", color = Lull.Text, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        IconButton(onClick = onMenu, modifier = Modifier.size(48.dp)) {
            Icon(Icons.Rounded.MoreVert, "Menu", tint = Lull.Text)
        }
    }
}

/** While scrolling down the bar shrinks to a slim pill; tap it to bring the bar back. */
@Composable
private fun CompactBar(lull: LullState, tab: TabSessionState?, onExpand: () -> Unit) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Row(
            Modifier.height(34.dp).clip(CircleShape).background(Lull.Bar).clickable(onClick = onExpand)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(Color(lull.currentWorkspace.color)))
            Spacer(Modifier.width(8.dp))
            Text(
                hostOf(tab?.content?.url ?: BLANK).ifEmpty { "New tab" },
                color = Lull.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
            )
        }
    }
}

// ---------------- helpers ----------------

fun copyText(context: Context, text: String, label: String = "Link copied") {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Lull", text))
    Toast.makeText(context, label, Toast.LENGTH_SHORT).show()
}

fun shareText(context: Context, title: String, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, title)
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, "Share link").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
