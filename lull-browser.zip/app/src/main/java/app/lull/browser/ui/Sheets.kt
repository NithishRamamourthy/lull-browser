package app.lull.browser.ui

import android.graphics.Bitmap
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.lull.browser.BLANK
import app.lull.browser.Essential
import app.lull.browser.LullState
import app.lull.browser.PRIVATE_WS
import app.lull.browser.WORKSPACE_COLORS
import app.lull.browser.components
import app.lull.browser.hostOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import mozilla.components.browser.state.action.ContentAction
import mozilla.components.browser.state.action.WebExtensionAction
import mozilla.components.browser.state.selector.findTab
import mozilla.components.browser.state.state.BrowserState
import mozilla.components.browser.state.state.TabSessionState
import mozilla.components.browser.state.state.content.DownloadState
import mozilla.components.browser.storage.sync.SyncedDeviceTabs
import mozilla.components.concept.engine.HitResult
import mozilla.components.concept.engine.webextension.Action

/** A rounded letter tile standing in for a site icon. */
@Composable
fun Monogram(url: String, size: Int = 32) {
    val host = hostOf(url).ifEmpty { "?" }
    val color = Color(WORKSPACE_COLORS[(host.hashCode() and 0x7fffffff) % WORKSPACE_COLORS.size])
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape((size / 3).dp)).background(color),
        contentAlignment = Alignment.Center,
    ) {
        Text(host.first().uppercase(), color = Lull.Bg, fontWeight = FontWeight.ExtraBold, fontSize = (size * 0.42f).sp)
    }
}

/** A site's real icon when Firefox has one, otherwise a letter tile. */
@Composable
fun SiteIcon(url: String, icon: Bitmap?, size: Int = 32) {
    if (icon != null) {
        Image(
            icon.asImageBitmap(), null,
            Modifier.size(size.dp).clip(RoundedCornerShape((size / 3).dp)).background(Color.White).padding(3.dp),
        )
    } else {
        Monogram(url, size)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun EssentialsGrid(lull: LullState, onOpen: (Essential) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        lull.currentWorkspace.essentials.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                row.forEach { e ->
                    Column(
                        Modifier.weight(1f).height(76.dp).clip(RoundedCornerShape(18.dp)).background(Lull.Chip)
                            .combinedClickable(
                                onClick = { onOpen(e) },
                                onLongClick = { lull.removeEssential(e) },
                                onLongClickLabel = "Remove from Essentials",
                            ),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Monogram(e.url, 34)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            e.title.ifBlank { hostOf(e.url) }, color = Lull.Muted, fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 6.dp),
                        )
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

// ---------------- address editor ----------------

private data class Suggestion(val icon: ImageVector, val title: String, val subtitle: String?, val go: () -> Unit)

@Composable
fun AddressEditor(lull: LullState, tab: TabSessionState?, accent: Color, onDone: () -> Unit) {
    val c = LocalContext.current.components
    val start = tab?.content?.url?.takeIf { it != BLANK } ?: ""
    var value by remember { mutableStateOf(TextFieldValue(start, TextRange(0, start.length))) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    fun go(input: String) {
        if (input.isBlank()) return
        val url = lull.resolveInput(input)
        if (tab != null) c.sessionUseCases.loadUrl(url, tab.id) else lull.newTab(url)
        onDone()
    }

    val q = value.text.trim()
    var history by remember { mutableStateOf<List<Suggestion>>(emptyList()) }
    LaunchedEffect(q) {
        if (q.isEmpty()) { history = emptyList(); return@LaunchedEffect }
        history = withContext(Dispatchers.IO) {
            val bookmarks = c.bookmarksStorage.searchBookmarks(q, 3).getOrNull().orEmpty()
                .filter { it.url != null }
                .map { b -> Suggestion(Icons.Rounded.Star, b.title ?: hostOf(b.url!!), hostOf(b.url!!)) { go(b.url!!) } }
            val visits = c.historyStorage.getSuggestions(q, 5)
                .filter { h -> bookmarks.none { it.subtitle == hostOf(h.url) } }
                .map { h -> Suggestion(Icons.Rounded.History, h.title ?: hostOf(h.url), h.url) { go(h.url) } }
            bookmarks + visits
        }
    }
    val state = c.store.state
    val openTabs = if (q.isEmpty()) emptyList() else lull.tabsIn(state, lull.currentWorkspaceId)
        .filter { it.id != tab?.id && (it.content.title.contains(q, true) || it.content.url.contains(q, true)) }
        .take(3)
        .map { t -> Suggestion(Icons.Rounded.Tab, t.content.title.ifBlank { hostOf(t.content.url) }, "Switch to tab") { lull.select(t.id); onDone() } }
    val essentials = lull.currentWorkspace.essentials
        .filter { q.isEmpty() || it.title.contains(q, true) || it.url.contains(q, true) }.take(4)
        .map { e -> Suggestion(Icons.Rounded.PushPin, e.title.ifBlank { hostOf(e.url) }, hostOf(e.url)) { go(e.url) } }
    val search = if (q.isEmpty()) emptyList()
    else listOf(Suggestion(Icons.Rounded.Search, "Search ${lull.currentWorkspace.searchEngine} for “$q”", null) { go(q) })
    val all = search + openTabs + history + essentials

    Column(Modifier.fillMaxSize().background(Lull.Bg).systemBarsPadding().imePadding().padding(12.dp)) {
        LazyColumn(Modifier.weight(1f), reverseLayout = true, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(all) { s -> SuggestionRow(s.icon, s.title, s.subtitle, s.go) }
        }
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Lull.Bar).padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onDone, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Rounded.Close, "Cancel", tint = Lull.Text)
            }
            TextField(
                value = value,
                onValueChange = { value = it },
                singleLine = true,
                placeholder = { Text("Search or enter address", color = Lull.Muted) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go, autoCorrectEnabled = false),
                keyboardActions = KeyboardActions(onGo = { go(value.text) }),
                shape = RoundedCornerShape(16.dp),
                colors = lullFieldColors(accent),
                modifier = Modifier.weight(1f).focusRequester(focus),
            )
            IconButton(onClick = { go(value.text) }, modifier = Modifier.size(48.dp)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowForward, "Go", tint = accent)
            }
        }
    }
}

@Composable
fun lullFieldColors(accent: Color) = TextFieldDefaults.colors(
    focusedContainerColor = Lull.Field, unfocusedContainerColor = Lull.Field,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    cursorColor = accent, focusedTextColor = Lull.Text, unfocusedTextColor = Lull.Text,
    focusedLabelColor = Lull.Muted, unfocusedLabelColor = Lull.Muted,
)

@Composable
fun SuggestionRow(icon: ImageVector, title: String, subtitle: String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Lull.Muted, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Lull.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, color = Lull.Muted, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ---------------- tab sheet ----------------

private const val OTHER_DEVICES = "__devices"

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun TabSheet(
    state: BrowserState,
    lull: LullState,
    accent: Color,
    onDismiss: () -> Unit,
    onNewTab: () -> Unit,
    onManageWorkspaces: () -> Unit,
) {
    val c = LocalContext.current.components
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var showDevices by remember { mutableStateOf(false) }
    val signedIn = c.accountManager.authenticatedAccount() != null

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheet,
        containerColor = Lull.Sheet,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = { Box(Modifier.padding(top = 10.dp).size(40.dp, 5.dp).clip(CircleShape).background(Lull.Faint)) },
    ) {
        Column(
            Modifier.fillMaxWidth().fillMaxHeight(0.92f).padding(horizontal = 16.dp).padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (searching) {
                    TextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        placeholder = { Text("Search tabs", color = Lull.Muted) },
                        shape = RoundedCornerShape(14.dp), colors = lullFieldColors(accent), modifier = Modifier.weight(1f),
                    )
                } else {
                    Text("Tabs", color = Lull.Text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.width(4.dp))
                SquareButton(if (searching) Icons.Rounded.Close else Icons.Rounded.Search, if (searching) "Stop searching" else "Search tabs") {
                    searching = !searching; query = ""
                }
                Spacer(Modifier.width(4.dp))
                SquareButton(Icons.Rounded.KeyboardArrowDown, "Close tab sheet", onClick = onDismiss)
            }

            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val spaces = lull.workspaces + lull.privateWorkspace
                spaces.forEach { ws ->
                    val current = !showDevices && ws.id == lull.currentWorkspaceId
                    val count = lull.tabsIn(state, ws.id).size
                    Chip(if (ws.isPrivate) "Private · $count" else "${ws.name} · $count", Color(ws.color), current) {
                        showDevices = false
                        if (ws.isPrivate && count == 0) { lull.newTab(BLANK, PRIVATE_WS); onDismiss() } else lull.switchWorkspace(ws.id)
                    }
                }
                if (signedIn) Chip("Other devices", Color(0xFFC9C6D1), showDevices) { showDevices = true }
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Lull.Chip).clickable(onClick = onManageWorkspaces)
                        .semantics { contentDescription = "Manage workspaces" },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.GridView, null, tint = Lull.Text, modifier = Modifier.size(18.dp)) }
            }

            if (showDevices) {
                SyncedTabsList(lull, Modifier.weight(1f), onOpened = onDismiss)
                return@Column
            }

            if (lull.currentWorkspace.essentials.isNotEmpty() && !searching) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionLabel("Essentials")
                    EssentialsGrid(lull, onOpen = { lull.openEssential(it); onDismiss() })
                }
            }

            SectionLabel("Open tabs")
            val list = lull.tabsIn(state, lull.currentWorkspaceId).filter {
                query.isBlank() || it.content.title.contains(query, true) || it.content.url.contains(query, true)
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(list, key = { it.id }) { t ->
                    val current = t.id == state.selectedTabId || lull.split?.toList()?.contains(t.id) == true
                    Row(
                        Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (current) Lull.Field else Color.Transparent)
                            .combinedClickable(
                                onClick = { lull.select(t.id); onDismiss() },
                                onLongClick = { lull.togglePin(t.id) },
                                onLongClickLabel = if (lull.isPinned(t.id)) "Unpin tab" else "Pin tab",
                            )
                            .padding(start = 10.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        SiteIcon(t.content.url, t.content.icon)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                t.content.title.ifBlank { hostOf(t.content.url).ifEmpty { "New tab" } },
                                color = Lull.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                            Text(hostOf(t.content.url).ifEmpty { "New tab" }, color = Lull.Muted, fontSize = 12.5.sp, maxLines = 1)
                        }
                        if (lull.isPinned(t.id)) Icon(Icons.Rounded.PushPin, "Pinned", tint = Lull.Muted, modifier = Modifier.size(16.dp))
                        IconButton(onClick = { lull.closeTab(t.id) }, modifier = Modifier.size(44.dp)) {
                            Icon(Icons.Rounded.Close, "Close tab", tint = Lull.Muted, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    Modifier.height(52.dp).clip(RoundedCornerShape(18.dp)).background(Lull.Chip)
                        .clickable { if (lull.split != null) lull.exitSplit() else lull.enterSplit(); onDismiss() }
                        .padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.ViewAgenda, null, tint = Lull.Text, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (lull.split != null) "Unsplit" else "Split", color = Lull.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Row(
                    Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(18.dp)).background(accent).clickable(onClick = onNewTab),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Icon(Icons.Rounded.Add, null, tint = Lull.OnAccent, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("New tab", color = Lull.OnAccent, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                }
            }
        }
    }
}

/** Tabs open on your other Firefox devices, from Sync. */
@Composable
private fun SyncedTabsList(lull: LullState, modifier: Modifier, onOpened: () -> Unit) {
    val c = LocalContext.current.components
    var devices by remember { mutableStateOf<List<SyncedDeviceTabs>?>(null) }
    LaunchedEffect(Unit) { devices = withContext(Dispatchers.IO) { c.syncedTabsStorage.getSyncedDeviceTabs() } }
    LazyColumn(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        val list = devices
        when {
            list == null -> item { Text("Loading…", color = Lull.Muted) }
            list.isEmpty() -> item {
                Text("No tabs from other devices yet. Open Firefox on another device signed in to the same account.", color = Lull.Muted)
            }
            else -> list.forEach { device ->
                item { SectionLabel(device.device.displayName) }
                items(device.tabs) { tab ->
                    val entry = tab.active()
                    SuggestionRow(Icons.Rounded.Devices, entry.title.ifBlank { hostOf(entry.url) }, hostOf(entry.url)) {
                        lull.newTab(entry.url); onOpened()
                    }
                }
            }
        }
    }
}

@Composable
private fun Chip(label: String, color: Color, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.height(40.dp).clip(CircleShape).background(if (selected) color else Lull.Chip)
            .clickable(onClick = onClick).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (!selected) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(7.dp))
        }
        Text(
            label, color = if (selected) Lull.OnAccent else Lull.Text, fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
        )
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text.uppercase(), color = Lull.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
}

@Composable
fun SquareButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Lull.Chip).clickable(onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = Lull.Text, modifier = Modifier.size(20.dp)) }
}

// ---------------- menu ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuSheet(
    state: BrowserState,
    lull: LullState,
    tab: TabSessionState?,
    accent: Color,
    onDismiss: () -> Unit,
    onFind: () -> Unit,
    onOpen: (Screen) -> Unit,
) {
    val context = LocalContext.current
    val c = context.components
    val scope = rememberCoroutineScope()
    var bookmarked by remember { mutableStateOf(false) }
    val url = tab?.content?.url ?: BLANK
    LaunchedEffect(url) {
        bookmarked = url != BLANK && withContext(Dispatchers.IO) {
            c.bookmarksStorage.getBookmarksWithUrl(url).getOrNull().orEmpty().isNotEmpty()
        }
    }
    val account = c.accountManager.accountProfile()

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Lull.Sheet) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 12.dp).padding(bottom = 20.dp)) {
            if (tab != null) {
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    QuickAction(Icons.AutoMirrored.Rounded.ArrowForward, "Forward", tab.content.canGoForward) {
                        c.sessionUseCases.goForward(tab.id); onDismiss()
                    }
                    if (tab.content.loading) {
                        QuickAction(Icons.Rounded.Close, "Stop", true) { c.sessionUseCases.stopLoading(tab.id); onDismiss() }
                    } else {
                        QuickAction(Icons.Rounded.Refresh, "Reload", true) { c.sessionUseCases.reload(tab.id); onDismiss() }
                    }
                    QuickAction(if (bookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder, if (bookmarked) "Saved" else "Bookmark", url != BLANK) {
                        scope.launch {
                            withContext(Dispatchers.IO) {
                                val existing = c.bookmarksStorage.getBookmarksWithUrl(url).getOrNull().orEmpty()
                                if (existing.isEmpty()) {
                                    c.bookmarksStorage.addItem("mobile______", url, tab.content.title.ifBlank { hostOf(url) }, null)
                                } else {
                                    existing.forEach { c.bookmarksStorage.deleteNode(it.guid) }
                                }
                            }
                            onDismiss()
                        }
                    }
                    QuickAction(Icons.Rounded.Share, "Share", url != BLANK) { shareText(context, tab.content.title, url); onDismiss() }
                }

                ExtensionActions(state, tab, onDismiss)

                HorizontalDivider(color = Lull.Chip)
                MenuRow(Icons.Rounded.Search, "Find in page", onClick = onFind)
                if (!lull.currentWorkspace.isPrivate) {
                    val essential = lull.isEssential(url)
                    MenuRow(if (essential) Icons.Rounded.Star else Icons.Rounded.StarBorder, if (essential) "Remove from Essentials" else "Add to Essentials") {
                        lull.toggleEssential(url, tab.content.title); onDismiss()
                    }
                }
                MenuRow(Icons.Rounded.PushPin, if (lull.isPinned(tab.id)) "Unpin tab" else "Pin tab") { lull.togglePin(tab.id); onDismiss() }
                MenuRow(Icons.Rounded.ViewAgenda, if (lull.split != null) "Exit split view" else "Split view") {
                    if (lull.split != null) lull.exitSplit() else lull.enterSplit(); onDismiss()
                }
                MenuRow(Icons.Rounded.DesktopWindows, if (tab.content.desktopMode) "Mobile site" else "Desktop site") {
                    c.sessionUseCases.requestDesktopSite(!tab.content.desktopMode, tab.id); onDismiss()
                }
                MenuRow(Icons.Rounded.ContentCopy, "Copy link") { copyText(context, url); onDismiss() }
            }
            MenuRow(Icons.Rounded.VisibilityOff, "New private tab") { lull.newTab(BLANK, PRIVATE_WS); onDismiss() }
            HorizontalDivider(color = Lull.Chip)
            MenuRow(Icons.Rounded.Bookmarks, "Bookmarks") { onOpen(Screen.Bookmarks) }
            MenuRow(Icons.Rounded.History, "History") { onOpen(Screen.History) }
            MenuRow(Icons.Rounded.Key, "Passwords") { onOpen(Screen.Passwords) }
            MenuRow(Icons.Rounded.Extension, "Extensions") { onOpen(Screen.Extensions) }
            MenuRow(Icons.Rounded.AccountCircle, account?.email?.let { "Firefox Account · $it" } ?: "Sign in to sync") { onOpen(Screen.Account) }
            MenuRow(Icons.Rounded.GridView, "Workspaces") { onOpen(Screen.Workspaces) }
            MenuRow(Icons.Rounded.Settings, "Settings") { onOpen(Screen.Settings) }
            if (tab != null) MenuRow(Icons.Rounded.Close, "Close tab") { lull.closeTab(tab.id); onDismiss() }
        }
    }
}

/** Toolbar buttons that extensions add (for example uBlock Origin's), shown as a row. */
@Composable
private fun ExtensionActions(state: BrowserState, tab: TabSessionState, onDismiss: () -> Unit) {
    val actions = state.extensions.values
        .filter { it.enabled && it.browserAction != null }
        .mapNotNull { ext ->
            val global = ext.browserAction ?: return@mapNotNull null
            val action = global.copyWithOverride(tab.extensionState[ext.id]?.browserAction)
            Triple(ext.id, ext.name ?: "Extension", action)
        }
    if (actions.isEmpty()) return
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        actions.forEach { (id, name, action) ->
            key(id) { ExtensionActionButton(name, action) { action.onClick(); onDismiss() } }
        }
    }
}

@Composable
private fun ExtensionActionButton(name: String, action: Action, onClick: () -> Unit) {
    var icon by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(action) { icon = try { action.loadIcon?.invoke(96) } catch (e: Exception) { null } }
    Column(
        Modifier.width(72.dp).clip(RoundedCornerShape(16.dp)).clickable(enabled = action.enabled != false, onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            val bmp = icon
            if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.size(32.dp))
            else Icon(Icons.Rounded.Extension, null, tint = Lull.Text, modifier = Modifier.size(32.dp))
            if (!action.badgeText.isNullOrEmpty()) {
                Text(
                    action.badgeText!!, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.offset(x = 8.dp, y = (-4).dp).clip(CircleShape)
                        .background(action.badgeBackgroundColor?.let { Color(it) } ?: Color(0xFF555555)).padding(horizontal = 4.dp),
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(action.title ?: name, color = Lull.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun QuickAction(icon: ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.width(76.dp).clip(RoundedCornerShape(16.dp)).clickable(enabled = enabled, onClick = onClick).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = if (enabled) Lull.Text else Lull.Faint)
        Spacer(Modifier.height(6.dp))
        Text(label, color = if (enabled) Lull.Muted else Lull.Faint, fontSize = 12.sp)
    }
}

@Composable
fun MenuRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Lull.Muted, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, color = Lull.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ---------------- find in page ----------------

@Composable
fun FindBar(tab: TabSessionState, accent: Color, onClose: () -> Unit) {
    val c = LocalContext.current.components
    var text by remember { mutableStateOf("") }
    val session = tab.engineState.engineSession
    val result = tab.content.findResults.lastOrNull()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    DisposableEffect(tab.id) {
        onDispose {
            session?.clearFindMatches()
            c.store.dispatch(ContentAction.ClearFindResultsAction(tab.id))
        }
    }
    Row(
        Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(22.dp)).background(Lull.Bar).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        TextField(
            value = text,
            onValueChange = { text = it; if (it.isEmpty()) session?.clearFindMatches() else session?.findAll(it) },
            singleLine = true,
            placeholder = { Text("Find in page", color = Lull.Muted) },
            shape = RoundedCornerShape(16.dp),
            colors = lullFieldColors(accent),
            modifier = Modifier.weight(1f).focusRequester(focus),
        )
        if (result != null && text.isNotEmpty()) {
            Text(
                if (result.numberOfMatches == 0) "0/0" else "${result.activeMatchOrdinal + 1}/${result.numberOfMatches}",
                color = Lull.Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 8.dp),
            )
        }
        IconButton(onClick = { session?.findNext(false) }) { Icon(Icons.Rounded.KeyboardArrowUp, "Previous match", tint = Lull.Text) }
        IconButton(onClick = { session?.findNext(true) }) { Icon(Icons.Rounded.KeyboardArrowDown, "Next match", tint = Lull.Text) }
        IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Close find", tint = Lull.Text) }
    }
}

// ---------------- long-press on images, video, phone numbers… ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContextSheet(target: ContextTarget, lull: LullState, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val c = context.components
    val src = target.hit.src
    val saveable = target.hit is HitResult.IMAGE || target.hit is HitResult.VIDEO || target.hit is HitResult.AUDIO
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Lull.Sheet) {
        Column(Modifier.padding(horizontal = 12.dp).padding(bottom = 20.dp)) {
            Text(src, color = Lull.Muted, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(14.dp))
            if (src.startsWith("http")) {
                MenuRow(Icons.AutoMirrored.Rounded.OpenInNew, "Open in new tab") { lull.newTab(src, select = false); onDismiss() }
            }
            if (saveable) {
                MenuRow(Icons.Rounded.Download, "Save to Downloads") {
                    c.contextMenuUseCases.injectDownload(
                        target.tabId,
                        DownloadState(url = src, skipConfirmation = true, private = target.private),
                    )
                    onDismiss()
                }
            }
            MenuRow(Icons.Rounded.ContentCopy, "Copy") { copyText(context, src, "Copied"); onDismiss() }
            MenuRow(Icons.Rounded.Share, "Share") { shareText(context, "", src); onDismiss() }
        }
    }
}

// ---------------- Glance ----------------

/** Long-press a link: preview it in a card without leaving the page. */
@Composable
fun Glance(tabId: String, state: BrowserState, lull: LullState, accent: Color) {
    val context = LocalContext.current
    val tab = state.findTab(tabId) ?: return
    Dialog(
        onDismissRequest = { lull.closeGlance() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 14.dp).padding(top = 24.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Lull.Page)) {
                Row(
                    Modifier.fillMaxWidth().height(52.dp).background(Color(0xFFEAE6DF)).padding(start = 16.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Lock, null, tint = Color(0xFF4E4A44), modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(hostOf(tab.content.url), color = Color(0xFF4E4A44), fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                    IconButton(onClick = { copyText(context, tab.content.url) }) {
                        Icon(Icons.Rounded.ContentCopy, "Copy link", tint = Color(0xFF4E4A44), modifier = Modifier.size(18.dp))
                    }
                }
                EnginePane(tabId, Modifier.fillMaxSize())
            }
            Row(
                Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(22.dp)).background(Lull.Bar).padding(6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Box(
                    Modifier.width(52.dp).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(Lull.Field)
                        .clickable { lull.closeGlance() }.semantics { contentDescription = "Close glance" },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Close, null, tint = Lull.Text) }
                GlanceButton(Icons.Rounded.ViewAgenda, "Split", Lull.Field, Lull.Text, Modifier.weight(1f)) { lull.glanceToSplit() }
                GlanceButton(Icons.AutoMirrored.Rounded.OpenInNew, "Open as tab", accent, Lull.OnAccent, Modifier.weight(1.4f)) { lull.glanceToTab() }
            }
        }
    }
}

@Composable
private fun GlanceButton(icon: ImageVector, label: String, bg: Color, fg: Color, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(bg).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = fg, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
    }
}

// ---------------- extension pop-ups ----------------

/** The pop-up an extension shows when you tap its toolbar button. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtensionPopup(extensionId: String, state: BrowserState, lull: LullState) {
    val c = LocalContext.current.components
    val ext = state.extensions[extensionId]
    val session = ext?.popupSession
    fun close() {
        c.store.dispatch(WebExtensionAction.UpdatePopupSessionAction(extensionId, popupSession = null))
        lull.popupExtensionId = null
    }
    if (session == null) {
        LaunchedEffect(Unit) { if (ext?.popupSessionId == null) lull.popupExtensionId = null }
        return
    }
    ModalBottomSheet(onDismissRequest = ::close, containerColor = Lull.Sheet) {
        Text(
            ext?.name ?: "Extension", color = Lull.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        )
        SessionView(session, Modifier.fillMaxWidth().height(480.dp).padding(horizontal = 8.dp).padding(bottom = 16.dp))
    }
}
