package app.lull.browser

import android.content.Context
import mozilla.components.browser.errorpages.ErrorPages
import mozilla.components.concept.engine.EngineSession
import mozilla.components.concept.engine.request.ErrorType
import mozilla.components.concept.engine.request.RequestInterceptor

/**
 * Sees every page load. It finishes Firefox Account sign-in when Mozilla's login page redirects
 * back, and shows Firefox's friendly error pages when a site can't be reached.
 */
class LullRequestInterceptor(private val context: Context) : RequestInterceptor {

    override fun onLoadRequest(
        engineSession: EngineSession,
        uri: String,
        lastUri: String?,
        hasUserGesture: Boolean,
        isSameDomain: Boolean,
        isRedirect: Boolean,
        isDirectNavigation: Boolean,
        isSubframeRequest: Boolean,
    ): RequestInterceptor.InterceptionResponse? =
        context.components.accountsAuthFeature.interceptor.onLoadRequest(
            engineSession, uri, lastUri, hasUserGesture, isSameDomain, isRedirect, isDirectNavigation, isSubframeRequest,
        )

    override fun onErrorRequest(
        session: EngineSession,
        errorType: ErrorType,
        uri: String?,
    ): RequestInterceptor.ErrorResponse =
        RequestInterceptor.ErrorResponse(ErrorPages.createUrlEncodedErrorPage(context, errorType, uri))

    override fun interceptsAppInitiatedRequests() = true
}
