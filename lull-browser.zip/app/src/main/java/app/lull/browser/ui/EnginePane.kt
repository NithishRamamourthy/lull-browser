package app.lull.browser.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.viewinterop.AndroidView
import app.lull.browser.components
import mozilla.components.browser.engine.gecko.GeckoEngineView
import mozilla.components.concept.engine.EngineSession
import mozilla.components.feature.session.SessionFeature

/** Shows one tab's web page. Mozilla's SessionFeature keeps the view attached to that tab. */
@Composable
fun EnginePane(tabId: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val c = context.components
    val view = remember { GeckoEngineView(context) }
    DisposableEffect(tabId) {
        val feature = SessionFeature(c.store, c.sessionUseCases.goBack, c.sessionUseCases.goForward, view, tabId)
        feature.start()
        onDispose { feature.stop() }
    }
    DisposableEffect(Unit) { onDispose { view.release() } }
    AndroidView(factory = { view }, modifier = modifier)
}

/** Shows an engine session that isn't a tab, such as an extension's pop-up. */
@Composable
fun SessionView(session: EngineSession, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val view = remember { GeckoEngineView(context) }
    DisposableEffect(session) {
        view.render(session)
        onDispose { view.release() }
    }
    AndroidView(factory = { view }, modifier = modifier)
}

/**
 * Pages draw on their own surface, which Compose can't clip. Painting the background colour
 * into the corners gives the rounded look from the design.
 */
@Composable
fun CornerMask(radius: Dp, color: Color, modifier: Modifier = Modifier.fillMaxSize()) {
    Canvas(modifier) {
        val r = radius.toPx()
        val path = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height))
            addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r, r)))
        }
        drawPath(path, color)
    }
}
