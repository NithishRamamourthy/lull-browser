import org.gradle.api.artifacts.component.ModuleComponentIdentifier

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

/**
 * Mozilla Android Components, the libraries Firefox for Android is built from.
 * "159.+" picks the newest 159.x release, which brings the matching GeckoView engine with it.
 * To move to a newer Firefox, change this and the AGP/Kotlin versions to what that release uses.
 */
val mozac = "159.+"

android {
    namespace = "app.lull.browser"
    compileSdk {
        version = release(37) { minorApiLevel = 2 }
    }

    defaultConfig {
        applicationId = "app.lull.browser"
        minSdk = 26
        targetSdk = 37
        // CI passes the run number so every build installs as an update.
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "0.2.${System.getenv("GITHUB_RUN_NUMBER") ?: "0"}"

        // Modern phones are 64-bit ARM; this keeps the APK about a quarter of the size.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    signingConfigs {
        create("lull") {
            // A fixed key so each new build installs over the previous one.
            // See README: move this to GitHub Secrets before publishing the app anywhere.
            storeFile = file("lull.keystore")
            storePassword = "lullbrowser"
            keyAlias = "lull"
            keyPassword = "lullbrowser"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("lull")
        }
        debug {
            signingConfig = signingConfigs.getByName("lull")
        }
    }

    buildFeatures { compose = true }

    packaging {
        jniLibs { useLegacyPackaging = true }
    }
}

kotlin {
    jvmToolchain(17)
}

// service-sync-logins pulls in Glean, which GeckoView also ships; use GeckoView's copy.
configurations.configureEach {
    resolutionStrategy.capabilitiesResolution.withCapability("org.mozilla.telemetry:glean-native") {
        val geckoview = candidates.firstOrNull {
            val id = it.id
            id is ModuleComponentIdentifier && id.module.contains("geckoview")
        }
        if (geckoview != null) select(geckoview)
        because("use GeckoView's Glean instead of the standalone one")
    }
}

dependencies {
    // Browser engine and state
    implementation("org.mozilla.components:browser-engine-gecko:$mozac")
    implementation("org.mozilla.components:browser-state:$mozac")
    implementation("org.mozilla.components:browser-session-storage:$mozac")
    implementation("org.mozilla.components:browser-errorpages:$mozac")
    implementation("org.mozilla.components:concept-engine:$mozac")
    implementation("org.mozilla.components:concept-fetch:$mozac")
    implementation("org.mozilla.components:lib-state:$mozac")

    // Browser features: tabs, prompts, permissions, downloads, context menu
    implementation("org.mozilla.components:feature-tabs:$mozac")
    implementation("org.mozilla.components:feature-session:$mozac")
    implementation("org.mozilla.components:feature-prompts:$mozac")
    implementation("org.mozilla.components:feature-sitepermissions:$mozac")
    implementation("org.mozilla.components:feature-downloads:$mozac")
    implementation("org.mozilla.components:feature-contextmenu:$mozac")
    implementation("org.mozilla.components:feature-webcompat:$mozac")

    // Extensions
    implementation("org.mozilla.components:feature-addons:$mozac")
    implementation("org.mozilla.components:support-webextensions:$mozac")

    // Firefox Account, Sync, bookmarks, history, passwords
    implementation("org.mozilla.components:concept-storage:$mozac")
    implementation("org.mozilla.components:concept-sync:$mozac")
    implementation("org.mozilla.components:browser-storage-sync:$mozac")
    implementation("org.mozilla.components:service-firefox-accounts:$mozac")
    implementation("org.mozilla.components:service-sync-logins:$mozac")
    implementation("org.mozilla.components:service-sync-autofill:$mozac")
    implementation("org.mozilla.components:feature-accounts:$mozac")
    implementation("org.mozilla.components:feature-syncedtabs:$mozac")
    implementation("org.mozilla.components:lib-dataprotect:$mozac")
    implementation("org.mozilla.components:support-appservices:$mozac") // also provides RustHttpConfig

    implementation("org.mozilla.components:support-base:$mozac")
    implementation("org.mozilla.components:support-ktx:$mozac")
    implementation("org.mozilla.components:support-utils:$mozac")

    // AndroidX and Compose (versions match Firefox 159)
    implementation(platform("androidx.compose:compose-bom:2026.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended:1.7.8")
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.appcompat:appcompat:1.8.0")
    implementation("androidx.fragment:fragment:1.9.1")
    implementation("androidx.core:core-ktx:1.19.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.11.0")
    implementation("androidx.lifecycle:lifecycle-process:2.11.0")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("com.google.android.material:material:1.14.0")
}
